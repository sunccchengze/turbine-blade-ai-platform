export type QuestionType = 'choice' | 'fill' | 'short';
export type Difficulty = 'easy' | 'medium' | 'hard';

export interface Question {
  id: string;
  section: string; // 'practice-1-1', 'practice-1-2', 'practice-1-3', 'unit-test'
  sectionTitle: string;
  number: string;
  difficulty: Difficulty;
  type: QuestionType;
  stem: string;
  options?: string[];
  answer: string;
  explanation?: string;
}

export const questions: Question[] = [
  // ===== 练习 1.1（10 题）=====
  {
    id: 'U01-S1-Q01',
    section: 'practice-1-1',
    sectionTitle: '练习 1.1',
    number: 'Q01',
    difficulty: 'easy',
    type: 'choice',
    stem: '本项目当前有没有已冻结的 E4 数字？',
    options: [
      'A. 有，Spearman 已填',
      'B. 有，粗网格 −3.39 就是 E4',
      'C. 没有，决策指标全是 null',
      'D. 没有，但 About 页可以先写上'
    ],
    answer: 'C',
    explanation: 'E4 要求收敛 RANS 核过排序或增益。当前 `decision_metrics` 全是 null，没有任何 E4 级别的冻结数字。粗网格 −3.39 只是 E3（未收敛）。'
  },
  {
    id: 'U01-S1-Q02',
    section: 'practice-1-1',
    sectionTitle: '练习 1.1',
    number: 'Q02',
    difficulty: 'easy',
    type: 'choice',
    stem: '留出集 $R^2=0.9844$ 属于哪一档？',
    options: [
      'A. E0',
      'B. E1',
      'C. E2',
      'D. E4'
    ],
    answer: 'C',
    explanation: 'E2 是「代理/统计」级别，包括留出集指标、代理搜索结果等。$R^2$ 来自留出集评估，属于 E2。'
  },
  {
    id: 'U01-S1-Q03',
    section: 'practice-1-1',
    sectionTitle: '练习 1.1',
    number: 'Q03',
    difficulty: 'medium',
    type: 'fill',
    stem: '公开数字只允许出自目录 ______ 。',
    answer: 'evidence/',
    explanation: '法定出处是 `evidence/metrics.json`、`evidence/claims.yaml`。所有对外数字必须从 evidence/ 目录读取。'
  },
  {
    id: 'U01-S1-Q04',
    section: 'practice-1-1',
    sectionTitle: '练习 1.1',
    number: 'Q04',
    difficulty: 'medium',
    type: 'fill',
    stem: 'SU2 粗网格 $\\mathrm{relrms}=$______，字段 `converged=`______。',
    answer: '−3.39；false',
    explanation: '残差停在 −3.39，未达到收敛阈值，所以 converged=false。这是 E3 级别。'
  },
  {
    id: 'U01-S1-Q05',
    section: 'practice-1-1',
    sectionTitle: '练习 1.1',
    number: 'Q05',
    difficulty: 'medium',
    type: 'short',
    stem: '把「SU2 已经跑过」自动升级成 E4，错在哪？',
    answer: 'E4 要求残差收敛到阈值，且需核过排序或增益。仅仅「跑过」只是 E3（求解器趋势），残差未收敛不能算物理闭环。'
  },
  {
    id: 'U01-S1-Q06',
    section: 'practice-1-1',
    sectionTitle: '练习 1.1',
    number: 'Q06',
    difficulty: 'medium',
    type: 'short',
    stem: '留出集 $n=100$ 和官方 test 200 是不是一套？官方 test 为何算不出 $R^2$？',
    answer: '不是一套。留出集是本项目从训练集划出的 100 个样本（seed=42），官方 test 200 的标签是隐藏的（用于排行榜），所以算不出 $R^2$。'
  },
  {
    id: 'U01-S1-Q07',
    section: 'practice-1-1',
    sectionTitle: '练习 1.1',
    number: 'Q07',
    difficulty: 'medium',
    type: 'short',
    stem: '「规划里写了细网格」能不能当 E4？',
    answer: '不能。规划是 E0 级别（打算做，还没做出数字）。E4 要求收敛的 RANS 结果，规划不产生数字。'
  },
  {
    id: 'U01-S1-Q08',
    section: 'practice-1-1',
    sectionTitle: '练习 1.1',
    number: 'Q08',
    difficulty: 'medium',
    type: 'short',
    stem: '同一句「效率提高了 5.4%」，怎样写是 E2，怎样写就假冒 E4？',
    answer: 'E2 写法：「代理预测最高效率相对训练均值约 +5.4%」。假冒 E4 写法：「优化后叶片效率提高了 5.4%」——暗示已有收敛 CFD 验证，但实际没有。'
  },
  {
    id: 'U01-S1-Q09',
    section: 'practice-1-1',
    sectionTitle: '练习 1.1',
    number: 'Q09',
    difficulty: 'medium',
    type: 'short',
    stem: '为什么网站、信、README 必须共用 `evidence/`？',
    answer: '防止各处各写一套数。单一数据源保证一致性，修改时只需改一处，避免信息不同步造成的诚信问题。'
  },
  {
    id: 'U01-S1-Q10',
    section: 'practice-1-1',
    sectionTitle: '练习 1.1',
    number: 'Q10',
    difficulty: 'hard',
    type: 'short',
    stem: '有人建议把 E3 改名叫「已验证」。列出三条反对理由。',
    answer: '1. E3 残差未收敛，结果不可信，「验证」暗示通过；2. 「已验证」让外行误以为物理闭环完成；3. E4 才是真正的验证级别，E3 只是「趋势」，改名会模糊等级边界。'
  },

  // ===== 练习 1.2（10 题）=====
  {
    id: 'U01-S2-Q01',
    section: 'practice-1-2',
    sectionTitle: '练习 1.2',
    number: 'Q01',
    difficulty: 'easy',
    type: 'choice',
    stem: '站的对外名称是',
    options: [
      'A. 叶轮机械 MDO 平台',
      'B. 气动代理筛选站',
      'C. 可制造叶片优化站',
      'D. 全工况智能设计器'
    ],
    answer: 'B',
    explanation: '「气动代理筛选站」是法定对外名。A 涉及 MDO（未接入结构/热），C 涉及「可制造」（无几何旋钮），D 涉及「全工况」（禁词）。'
  },
  {
    id: 'U01-S2-Q02',
    section: 'practice-1-2',
    sectionTitle: '练习 1.2',
    number: 'Q02',
    difficulty: 'easy',
    type: 'choice',
    stem: '下列哪句现在可以当现状对外说？',
    options: [
      'A. 校准的 95% 置信区间',
      'B. 可制造的 Pareto 最优叶片',
      'C. 粗网格残差停在 −3.39，未收敛',
      'D. 已用 PINN 嵌入 N-S'
    ],
    answer: 'C',
    explanation: 'A、B、D 都在禁词表里。C 带「未收敛」限定词，是合规的 E3 陈述。'
  },
  {
    id: 'U01-S2-Q03',
    section: 'practice-1-2',
    sectionTitle: '练习 1.2',
    number: 'Q03',
    difficulty: 'medium',
    type: 'fill',
    stem: 'η 通道 MC Dropout 经验覆盖率是 ______%。',
    answer: '65',
    explanation: '效率通道的经验覆盖率约 65%，低于名义 95%，说明不确定性估计未校准。'
  },
  {
    id: 'U01-S2-Q04',
    section: 'practice-1-2',
    sectionTitle: '练习 1.2',
    number: 'Q04',
    difficulty: 'medium',
    type: 'fill',
    stem: 'KIT 303 秒在叙事里是______（填「引子」或「本项目对象」）。',
    answer: '引子',
    explanation: 'KIT 303 秒是引出问题的背景故事（为什么需要代理），本项目对象是 Rotor 37 数据集。'
  },
  {
    id: 'U01-S2-Q05',
    section: 'practice-1-2',
    sectionTitle: '练习 1.2',
    number: 'Q05',
    difficulty: 'medium',
    type: 'short',
    stem: '`status: empty` 的 claim 可以写进摘要吗？',
    answer: '不可以。empty 表示该声明没有支撑证据，只有 `status: verified` 的 claim 才能对外说。'
  },
  {
    id: 'U01-S2-Q06',
    section: 'practice-1-2',
    sectionTitle: '练习 1.2',
    number: 'Q06',
    difficulty: 'medium',
    type: 'short',
    stem: '「代理筛路，物理定音」现在「定音」完成了没有？',
    answer: '没有。「定音」需要收敛 RANS（E4），当前 decision_metrics 全是 null，物理闭环未完成。'
  },
  {
    id: 'U01-S2-Q07',
    section: 'practice-1-2',
    sectionTitle: '练习 1.2',
    number: 'Q07',
    difficulty: 'medium',
    type: 'short',
    stem: '把 Pareto 叫「最优叶片」至少错在哪两处？',
    answer: '1. Pareto 是特征空间的非支配点，不是真实叶片几何；2. 没有收敛 CFD 验证，不能说「最优」；（补充：也没有几何旋钮映射回可制造叶片）。'
  },
  {
    id: 'U01-S2-Q08',
    section: 'practice-1-2',
    sectionTitle: '练习 1.2',
    number: 'Q08',
    difficulty: 'medium',
    type: 'short',
    stem: '给郭老师的信里点宋老师名字，纪律是什么？',
    answer: '必须经宋老师本人同意后才能在信中提及其名字。未经同意点名可能涉及不当归属或越权。'
  },
  {
    id: 'U01-S2-Q09',
    section: 'practice-1-2',
    sectionTitle: '练习 1.2',
    number: 'Q09',
    difficulty: 'medium',
    type: 'short',
    stem: '改错：「我们在 74 维设计空间里做了 MDO。」',
    answer: '错误：1. 74 维是统计量/特征空间，不是设计空间；2. 没有结构/热接入不能叫 MDO。改为：「我们在 74 维特征空间里做了气动代理筛选。」'
  },
  {
    id: 'U01-S2-Q10',
    section: 'practice-1-2',
    sectionTitle: '练习 1.2',
    number: 'Q10',
    difficulty: 'hard',
    type: 'short',
    stem: '写一条「差一个词就从 E2 滑到假 E4」的句子并改正。',
    answer: '错句：「优化后效率提升了 5.4%。」（暗示物理验证）。改正：「代理预测的最高效率相对训练均值提升约 5.4%。」加「代理预测」「训练均值」限定。'
  },

  // ===== 练习 1.3（10 题）=====
  {
    id: 'U01-S3-Q01',
    section: 'practice-1-3',
    sectionTitle: '练习 1.3',
    number: 'Q01',
    difficulty: 'easy',
    type: 'choice',
    stem: 'Rotor 37 是',
    options: [
      'A. 涡轮静子',
      'B. 涡扇整机',
      'C. 跨音速压气机转子',
      'D. 实验台实测叶片'
    ],
    answer: 'C',
    explanation: 'NASA Rotor 37 是经典的跨音速轴流压气机转子测试用例。禁止把它叫成「涡轮」。'
  },
  {
    id: 'U01-S3-Q02',
    section: 'practice-1-3',
    sectionTitle: '练习 1.3',
    number: 'Q02',
    difficulty: 'easy',
    type: 'choice',
    stem: '`/generate` 页实际是',
    options: [
      'A. 扩散模型长新叶',
      'B. 库内近邻检索',
      'C. CST 反设计',
      'D. 收敛 RANS'
    ],
    answer: 'B',
    explanation: '生成页实际是库内近邻检索，不是扩散模型生成新叶片。要记住「它不是什么」。'
  },
  {
    id: 'U01-S3-Q03',
    section: 'practice-1-3',
    sectionTitle: '练习 1.3',
    number: 'Q03',
    difficulty: 'medium',
    type: 'fill',
    stem: '生产端 UQ 用的是______（填「实时 100 次 Dropout」或「预计算常数 σ」）。',
    answer: '预计算常数 σ',
    explanation: '生产 API 不是每次请求都跑 100 次 MC Dropout，而是用预计算的常数 σ。'
  },
  {
    id: 'U01-S3-Q04',
    section: 'practice-1-3',
    sectionTitle: '练习 1.3',
    number: 'Q04',
    difficulty: 'medium',
    type: 'fill',
    stem: 'E3 和 E4 的分界是残差有没有到______。',
    answer: '收敛阈值',
    explanation: 'E3 是求解器跑过但未收敛，E4 是收敛 RANS。分界点是残差是否达到预设的收敛阈值。'
  },
  {
    id: 'U01-S3-Q05',
    section: 'practice-1-3',
    sectionTitle: '练习 1.3',
    number: 'Q05',
    difficulty: 'medium',
    type: 'short',
    stem: '「最高效率 0.9173」少哪两个限定词就不能对外说？',
    answer: '1.「代理」（或「代理预测的」）；2.「相对训练均值」。缺这两个词会暗示是 CFD 验证结果。'
  },
  {
    id: 'U01-S3-Q06',
    section: 'practice-1-3',
    sectionTitle: '练习 1.3',
    number: 'Q06',
    difficulty: 'medium',
    type: 'short',
    stem: '`decision_metrics` 为何全是 null？',
    answer: '因为没有收敛的 RANS 结果来核验代理预测的排序或增益。E4 级别的验证未完成。'
  },
  {
    id: 'U01-S3-Q07',
    section: 'practice-1-3',
    sectionTitle: '练习 1.3',
    number: 'Q07',
    difficulty: 'medium',
    type: 'short',
    stem: '信里写「PINN 约束了 N-S」为何违规？损失里实际有什么？',
    answer: '违规因为 PINN 和 N-S 约束都在禁词表。损失里实际有物理残差项（如质量/动量守恒的软约束），但不是完整 N-S 方程嵌入。'
  },
  {
    id: 'U01-S3-Q08',
    section: 'practice-1-3',
    sectionTitle: '练习 1.3',
    number: 'Q08',
    difficulty: 'medium',
    type: 'short',
    stem: '结构、热都没接时为什么不能叫 MDO？',
    answer: 'MDO = Multi-Disciplinary Optimization，需要多学科耦合。只有气动单学科，叫 MDO 是夸大。'
  },
  {
    id: 'U01-S3-Q09',
    section: 'practice-1-3',
    sectionTitle: '练习 1.3',
    number: 'Q09',
    difficulty: 'medium',
    type: 'short',
    stem: '`do_not_freeze` 里三类数各举一个。',
    answer: '1. 融合 $R^2$ 区间；2. conformal 93.5–96.5%；3. $100{,}000\\times$ 加速比。这些未经独立复现，不能当结论用。'
  },
  {
    id: 'U01-S3-Q10',
    section: 'practice-1-3',
    sectionTitle: '练习 1.3',
    number: 'Q10',
    difficulty: 'hard',
    type: 'short',
    stem: '郭老师问：「你是不是已经做完气动优化了？」不超过三句、不越档。',
    answer: '「代理模型在留出集上 $R^2$ 达到 0.98，筛出了特征空间的非支配解。但收敛 CFD 验证还没跑完，所以还不能说物理闭环完成。」'
  },

  // ===== 单元卷 U01（30 题）=====
  {
    id: 'U01-E-Q01',
    section: 'unit-test',
    sectionTitle: '单元卷 U01',
    number: 'Q01',
    difficulty: 'easy',
    type: 'choice',
    stem: 'E2 指',
    options: [
      'A. 规划',
      'B. 静态定义',
      'C. 代理 / 统计',
      'D. 收敛 RANS'
    ],
    answer: 'C',
    explanation: 'E0=规划，E1=静态，E2=代理/统计，E3=求解器趋势，E4=物理闭环（收敛 RANS）。'
  },
  {
    id: 'U01-E-Q02',
    section: 'unit-test',
    sectionTitle: '单元卷 U01',
    number: 'Q02',
    difficulty: 'easy',
    type: 'choice',
    stem: '决策指标现在是',
    options: [
      'A. 已填 Spearman',
      'B. 全部 null',
      'C. 用代理自比填过',
      'D. 只填了 Top-k'
    ],
    answer: 'B',
    explanation: '当前 decision_metrics 全是 null，因为没有收敛 RANS 来验证。'
  },
  {
    id: 'U01-E-Q03',
    section: 'unit-test',
    sectionTitle: '单元卷 U01',
    number: 'Q03',
    difficulty: 'easy',
    type: 'choice',
    stem: '官方 test 200 组标签',
    options: [
      'A. 公开，已报 $R^2$',
      'B. 隐藏，算不出 $R^2$',
      'C. 与 holdout 是同一 100 点',
      'D. 只有几何没有工况'
    ],
    answer: 'B',
    explanation: '官方 test 200 的标签是隐藏的（用于排行榜），所以本地算不出 $R^2$。'
  },
  {
    id: 'U01-E-Q04',
    section: 'unit-test',
    sectionTitle: '单元卷 U01',
    number: 'Q04',
    difficulty: 'easy',
    type: 'choice',
    stem: 'Rotor 37 载体',
    options: [
      'A. 涡轮转子',
      'B. 压气机转子',
      'C. 风扇整级',
      'D. 燃烧室'
    ],
    answer: 'B',
    explanation: 'NASA Rotor 37 是跨音速轴流压气机转子。把它叫涡轮是禁止的。'
  },
  {
    id: 'U01-E-Q05',
    section: 'unit-test',
    sectionTitle: '单元卷 U01',
    number: 'Q05',
    difficulty: 'medium',
    type: 'choice',
    stem: '生产 API 的 UQ',
    options: [
      'A. 每个请求实时 100 次 Dropout',
      'B. 预计算常数 σ',
      'C. 已 conformal 校准',
      'D. 不用 σ'
    ],
    answer: 'B',
    explanation: '生产端用预计算常数 σ，不是实时 MC Dropout。conformal 校准未完成。'
  },
  {
    id: 'U01-E-Q06',
    section: 'unit-test',
    sectionTitle: '单元卷 U01',
    number: 'Q06',
    difficulty: 'medium',
    type: 'choice',
    stem: '生成页法定说法',
    options: [
      'A. 扩散生成',
      'B. 库内近邻检索',
      'C. FFD 新叶',
      'D. 可加工 CAD'
    ],
    answer: 'B',
    explanation: '/generate 实际是库内近邻检索，不是扩散模型或 FFD 生成新叶片。'
  },
  {
    id: 'U01-E-Q07',
    section: 'unit-test',
    sectionTitle: '单元卷 U01',
    number: 'Q07',
    difficulty: 'easy',
    type: 'fill',
    stem: '冻住 $R^2$：π = ______，η = ______，ṁ = ______。',
    answer: '0.9844；0.9608；0.9777',
    explanation: '三个气动输出在留出集上的 $R^2$ 值。'
  },
  {
    id: 'U01-E-Q08',
    section: 'unit-test',
    sectionTitle: '单元卷 U01',
    number: 'Q08',
    difficulty: 'easy',
    type: 'fill',
    stem: '粗网格 relrms = ______，收敛了吗？______。',
    answer: '−3.39；没有（或 false）',
    explanation: '残差停在 −3.39，未达到收敛阈值。'
  },
  {
    id: 'U01-E-Q09',
    section: 'unit-test',
    sectionTitle: '单元卷 U01',
    number: 'Q09',
    difficulty: 'medium',
    type: 'fill',
    stem: '站名：______。',
    answer: '气动代理筛选站',
    explanation: '法定对外名称。'
  },
  {
    id: 'U01-E-Q10',
    section: 'unit-test',
    sectionTitle: '单元卷 U01',
    number: 'Q10',
    difficulty: 'medium',
    type: 'fill',
    stem: 'E3 句子三件套：粗网格 / 一阶 / ______。',
    answer: '未收敛',
    explanation: 'E3 陈述必须带「粗网格」「一阶」「未收敛」三个限定词。'
  },
  {
    id: 'U01-E-Q11',
    section: 'unit-test',
    sectionTitle: '单元卷 U01',
    number: 'Q11',
    difficulty: 'medium',
    type: 'fill',
    stem: '三个气动输出符号：______、______、______。',
    answer: 'π（压比）；η（效率）；ṁ（流量）',
    explanation: '代理模型预测的三个气动性能指标。'
  },
  {
    id: 'U01-E-Q12',
    section: 'unit-test',
    sectionTitle: '单元卷 U01',
    number: 'Q12',
    difficulty: 'medium',
    type: 'fill',
    stem: 'η 经验覆盖率 ______%；名义水平 ______%。',
    answer: '65；95',
    explanation: '效率通道 MC Dropout 经验覆盖率约 65%，远低于名义 95%，说明 UQ 未校准。'
  },
  {
    id: 'U01-E-Q13',
    section: 'unit-test',
    sectionTitle: '单元卷 U01',
    number: 'Q13',
    difficulty: 'medium',
    type: 'short',
    stem: 'holdout 和官方 test 为何不能混报 $R^2$？',
    answer: 'holdout 是本项目从训练集划出的 100 点（标签可见），官方 test 200 标签隐藏（用于排行榜）。数据来源不同，不能混报。'
  },
  {
    id: 'U01-E-Q14',
    section: 'unit-test',
    sectionTitle: '单元卷 U01',
    number: 'Q14',
    difficulty: 'medium',
    type: 'short',
    stem: '「0.9173」最低限定词清单。',
    answer: '1. 代理预测（不是 CFD）；2. 最高效率（不是平均）；3. 相对训练均值（基准是什么）。'
  },
  {
    id: 'U01-E-Q15',
    section: 'unit-test',
    sectionTitle: '单元卷 U01',
    number: 'Q15',
    difficulty: 'medium',
    type: 'short',
    stem: '+5.4% 为何不能和季路成组 +1.2% 比？',
    answer: '基准不同：本项目 +5.4% 是相对训练均值，季路成组的 +1.2% 可能是相对基线设计或其他基准。基准不统一不能直接比较。'
  },
  {
    id: 'U01-E-Q16',
    section: 'unit-test',
    sectionTitle: '单元卷 U01',
    number: 'Q16',
    difficulty: 'medium',
    type: 'short',
    stem: 'C06、C07 各说什么？',
    answer: 'C06：代理在留出集上的预测精度（$R^2$）；C07：代理搜索到的最优解及相对增益。两者都是 E2 级别。'
  },
  {
    id: 'U01-E-Q17',
    section: 'unit-test',
    sectionTitle: '单元卷 U01',
    number: 'Q17',
    difficulty: 'medium',
    type: 'short',
    stem: '「物理约束」在本项目指什么、不指什么？',
    answer: '指：损失函数里的守恒软惩罚项。不指：完整 N-S 方程嵌入、PINN 硬约束、收敛 RANS 验证。'
  },
  {
    id: 'U01-E-Q18',
    section: 'unit-test',
    sectionTitle: '单元卷 U01',
    number: 'Q18',
    difficulty: 'medium',
    type: 'short',
    stem: '加速比怎样写才不和 `do_not_freeze` 冲突？',
    answer: '写「初步估计约 $10^5$ 量级」或「待独立复现后冻结」，不能写「加速 100,000 倍」作为确定结论。'
  },
  {
    id: 'U01-E-Q19',
    section: 'unit-test',
    sectionTitle: '单元卷 U01',
    number: 'Q19',
    difficulty: 'medium',
    type: 'short',
    stem: '信里可以写 TNO 吗？可以写「我做了 TNO」吗？',
    answer: '可以提 TNO 比赛作为背景。但不能写「我做了 TNO」暗示独立完成，需说明是组队参与或基于其数据集。'
  },
  {
    id: 'U01-E-Q20',
    section: 'unit-test',
    sectionTitle: '单元卷 U01',
    number: 'Q20',
    difficulty: 'medium',
    type: 'short',
    stem: '三维预览缺哪句话会骗过外行？',
    answer: '缺「这是库内近邻检索的可视化，不是生成的新叶片」或「不代表可制造几何」。外行可能误以为是优化后的真实叶片。'
  },
  {
    id: 'U01-E-Q21',
    section: 'unit-test',
    sectionTitle: '单元卷 U01',
    number: 'Q21',
    difficulty: 'medium',
    type: 'short',
    stem: '特征空间和设计空间差在哪个可逆性？',
    answer: '特征空间 → 设计空间不可逆。74 维统计量无法唯一映射回叶片几何参数（CST/FFD 控制点）。'
  },
  {
    id: 'U01-E-Q22',
    section: 'unit-test',
    sectionTitle: '单元卷 U01',
    number: 'Q22',
    difficulty: 'medium',
    type: 'short',
    stem: '为什么现在不能说「全工况」？',
    answer: '「全工况」在禁词表。当前只在设计点附近训练/预测，没有覆盖失速、喘振等边界工况。'
  },
  {
    id: 'U01-E-Q23',
    section: 'unit-test',
    sectionTitle: '单元卷 U01',
    number: 'Q23',
    difficulty: 'medium',
    type: 'short',
    stem: 'Reviewer 该读什么、不该读什么？',
    answer: '该读：evidence/ 目录、claims.yaml、CLAIM_EVIDENCE.md。不该读：do_not_freeze 里的未复现数、规划文档当结论。'
  },
  {
    id: 'U01-E-Q24',
    section: 'unit-test',
    sectionTitle: '单元卷 U01',
    number: 'Q24',
    difficulty: 'medium',
    type: 'short',
    stem: '别人要复现 0.9173，必须锁住哪几样？',
    answer: '1. 数据集版本和划分（seed=42）；2. 模型架构和超参；3. 优化算法和参数；4. 随机种子。'
  },
  {
    id: 'U01-E-Q25',
    section: 'unit-test',
    sectionTitle: '单元卷 U01',
    number: 'Q25',
    difficulty: 'medium',
    type: 'short',
    stem: '指出错句：「粗网格跑通了，物理闭环完成了一半。」',
    answer: '错误：物理闭环（E4）没有「一半」，要么收敛要么没有。粗网格未收敛只是 E3，不能量化为「一半」。'
  },
  {
    id: 'U01-E-Q26',
    section: 'unit-test',
    sectionTitle: '单元卷 U01',
    number: 'Q26',
    difficulty: 'medium',
    type: 'short',
    stem: '指出错句：「覆盖率 65% 说明模型只有 65 分。」',
    answer: '错误：覆盖率是 UQ 校准指标，不是模型精度评分。65% 覆盖率说明不确定性估计偏窄，不是预测准确率。'
  },
  {
    id: 'U01-E-Q27',
    section: 'unit-test',
    sectionTitle: '单元卷 U01',
    number: 'Q27',
    difficulty: 'medium',
    type: 'short',
    stem: '未加定语的「收敛」容易和哪两种搅在一起？',
    answer: '1. 覆盖率收敛（UQ 校准的收敛）；2. 蒙特卡洛估计量收敛（采样收敛）。本项目的「收敛」专指 RANS 残差收敛。'
  },
  {
    id: 'U01-E-Q28',
    section: 'unit-test',
    sectionTitle: '单元卷 U01',
    number: 'Q28',
    difficulty: 'hard',
    type: 'short',
    stem: '设计一道「越档检测」题并给标准答案。',
    answer: '题目：「下列哪句越档？A. 代理 $R^2$=0.98 B. 优化后效率提升 5% C. 规划做细网格」答案：B 越档（代理结果冒充物理验证）。'
  },
  {
    id: 'U01-E-Q29',
    section: 'unit-test',
    sectionTitle: '单元卷 U01',
    number: 'Q29',
    difficulty: 'hard',
    type: 'short',
    stem: '郭老师看 About 30 秒：哪三行必须看见？哪三行有害？',
    answer: '必须看见：1. 当前档位 E2-E3；2. E4 指标为 null；3. 站名「气动代理筛选站」。有害：1. MDO；2. 可制造最优叶片；3. 已验证的 95% CI。'
  },
  {
    id: 'U01-E-Q30',
    section: 'unit-test',
    sectionTitle: '单元卷 U01',
    number: 'Q30',
    difficulty: 'hard',
    type: 'short',
    stem: '「想发 CJA」现在是 E 几？还缺的最小闭环不超过五条。',
    answer: '现在是 E2（代理结果）。缺：1. 收敛 RANS（至少粗网格收敛）；2. Spearman 排序验证；3. Top-k 增益验证；4. 细网格/多点确认；5. 可复现的脚本和数据包。'
  }
];

// Get all section IDs
export function getSections(): string[] {
  return ['practice-1-1', 'practice-1-2', 'practice-1-3', 'unit-test'];
}

export function getSectionTitle(sectionId: string): string {
  const titles: Record<string, string> = {
    'practice-1-1': '练习 1.1',
    'practice-1-2': '练习 1.2',
    'practice-1-3': '练习 1.3',
    'unit-test': '单元卷 U01'
  };
  return titles[sectionId] || sectionId;
}

export function getQuestionsBySection(sectionId: string): Question[] {
  return questions.filter(q => q.section === sectionId);
}
