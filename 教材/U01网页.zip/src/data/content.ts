export interface Section {
  id: string;
  number: string;
  title: string;
  content: string;
}

export interface TableData {
  headers: string[];
  rows: string[][];
}

export const unitTitle = "第 1 单元 · 红线与证据等级";
export const unitIntro = `本单元不讲叶片怎么转，先讲：**一句话能不能说，取决于它绑在哪一级证据上。**

郭老师若只问一句「你现在证明了什么」，答错等级比答错公式更糟。`;

export const sections: Section[] = [
  {
    id: 'section-1-1',
    number: '1.1',
    title: '画面：同一件事，五档说法',
    content: `想象桌上放着三样东西。

1. 一张纸，写着「我想用代理模型筛叶片」。
2. 一个已经训好的 ONNX 文件，和一张留出集上的 $R^2$ 表。
3. 一份 SU2 日志，残差掉到 $-3.39$ 就停了。

这三样说的都是「这个项目」，但它们不是同一档事实。把 2 说成「已经找到好叶片」，或把 3 说成「CFD 验证完了」，就是越档。

**证据等级**（Evidence grade）是给每句结论盖的章：

| 档 | 名字 | 这句话能靠什么站住 | 本项目例子 |
|---|---|---|---|
| E0 | 规划 | 打算做，还没做出数字 | 「下一步想改 CST」 |
| E1 | 静态 | 文件、定义、接口在，不依赖一次训练运气 | 「74 维是统计量，不是设计变量」 |
| E2 | 代理 / 统计 | 留出集、代理搜索、可复现脚本 | $R^2=0.9844$；$\\eta_{\\max}=0.9173$ |
| E3 | 求解器趋势 | 求解器跑过，但残差未到收敛阈值 | SU2 粗网格 $\\mathrm{relrms}=-3.39$ |
| E4 | 物理闭环 | 收敛 RANS（最好再加细网格/多点）核过排序或增益 | **现在没有。决策指标全是 null** |

法定出处：\`evidence/metrics.json\`、\`evidence/claims.yaml\`、\`docs/CLAIM_EVIDENCE.md\`。
网站、信、教材、嘴，不许各写一套数。

---

**拆词**

- **留出集**（holdout）：训练时完全没见过的样本。本项目 $n=100$，\`random_state=42\`。
- **收敛**（这里指 RANS 残差收敛）：离散方程的残差降到事先定的阈值。不是「覆盖率收敛」，也不是「蒙特卡洛估计量收敛」。三种收敛到 U10 再钉死。
- **对外可写**：写进给老师的信、写进 About 页的句子。未冻结的数（融合 $R^2$ 区间、conformal 93.5–96.5%、$100{,}000\\times$）列在 \`do_not_freeze_until_reproduced\`，教材当结论用就违规。`
  },
  {
    id: 'section-1-2',
    number: '1.2',
    title: '操作：一句话怎么对档',
    content: `操作规程只有四步。

1. 找出句子里的数字或动词（「找到了」「验证了」「优化了」）。
2. 问：这个动词的主语是代理，还是收敛的 RANS？
3. 去 \`evidence/claims.yaml\` 找有没有对应 \`status: verified\` 的条目。
4. 没有条目，或 \`decision_metrics\` 仍是 \`null\`，这句话就不能对外说满。

**例子对照表：**

| 句子 | 档 | 判 |
|---|---|---|
| 留出集上压比 $R^2=0.9844$ | E2 | 可写，必须带 $n=100$, seed=42 |
| 代理最高效率约 0.9173，相对训练均值约 +5.4% | E2 | 可写，必须带「代理」「相对训练均值」 |
| 找到了一片可制造的最优叶片 | — | 禁。没有几何旋钮，没有收敛 RANS |
| 粗网格残差停在 −3.39 | E3 | 可写，必须带「未收敛」 |
| 代理能正确排序设计 | E4 | 空。\`spearman_rank\` 现在是 null |

---

**禁词表**（信、页、答辩、教材练习的「对外句」里禁止当现状）：

- 多学科设计优化（在结构/热接入前）
- 可制造的 Pareto 最优叶片
- 校准的 95% 置信区间
- PINN（除非说「不是」）
- N-S 残差约束
- 全工况智能优化
- 把 Rotor 37 叫涡轮

**站的对外名： 气动代理筛选站。**`
  },
  {
    id: 'section-1-3',
    number: '1.3',
    title: '本项目的仓库地图（你两周要摸的路径）',
    content: `\`\`\`
evidence/metrics.json          冻住的数
evidence/claims.yaml           能对外说的句子
docs/郭老师发送包.md            信发出前的检查单
docs/暑期总结-致郭振东-发送正文.txt  粘贴进邮箱的正文
backend/models/surrogate_model.onnx
notebooks/04_residual_physics_model.ipynb
backend/scripts/calibrate_uq_p2.py
data/processed/pareto_front_solutions.csv
\`\`\`

线上站按页记住功能，不要被标题带跑：

| 页 | 它实际是 | 它不是 |
|---|---|---|
| \`/predict\` | 74 维滑块 → 三个气动标量 | 不是实时 MC Dropout（生产端常数 $\\sigma$） |
| \`/explore\` | 两维切片 | 不是全设计空间的 CFD |
| \`/optimize\` | 特征空间里的非支配点 | 不是可加工叶片 |
| \`/uq\` | 启发式带子 | 不是校准 95% CI |
| \`/generate\` | 库内近邻 | 不是扩散长新叶 |
| \`/about\` | 四档历史，第三档 HERE | 不是已完成的场算子 |

题型：每节 2 选 + 2 填 + 6 问；单元卷 6 选 + 6 填 + 18 问。`
  }
];
