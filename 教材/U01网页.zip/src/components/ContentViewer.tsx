import { sections, unitTitle, unitIntro } from '../data/content';
import MathText from './MathText';

export default function ContentViewer() {
  return (
    <div style={{ maxWidth: 800, margin: '0 auto' }}>
      {/* Unit Title */}
      <div id="section-intro" style={{ marginBottom: 48 }}>
        <h1
          style={{
            fontFamily: 'var(--font-heading)',
            fontSize: 32,
            fontWeight: 700,
            color: 'var(--color-text-primary)',
            margin: '0 0 16px',
            letterSpacing: '-0.02em',
          }}
        >
          {unitTitle}
        </h1>
        <div
          style={{
            fontSize: 17,
            lineHeight: 1.9,
            color: 'var(--color-text-primary)',
            fontFamily: 'var(--font-body)',
            padding: '20px 24px',
            background: 'var(--color-primary-soft)',
            borderRadius: 'var(--radius-lg)',
            borderLeft: '4px solid var(--color-primary)',
          }}
        >
          <MathText text={unitIntro} />
        </div>
      </div>

      {/* Sections */}
      {sections.map((section) => (
        <section
          key={section.id}
          id={section.id}
          style={{
            marginBottom: 56,
            scrollMarginTop: 24,
          }}
        >
          <h2
            style={{
              fontFamily: 'var(--font-heading)',
              fontSize: 24,
              fontWeight: 600,
              color: 'var(--color-text-primary)',
              margin: '0 0 20px',
              letterSpacing: '-0.02em',
              display: 'flex',
              alignItems: 'center',
              gap: 12,
            }}
          >
            <span
              style={{
                display: 'inline-flex',
                alignItems: 'center',
                justifyContent: 'center',
                width: 36,
                height: 36,
                borderRadius: 'var(--radius-md)',
                background: 'var(--color-primary)',
                color: 'white',
                fontSize: 16,
                fontWeight: 700,
              }}
            >
              {section.number}
            </span>
            {section.title}
          </h2>
          <div
            style={{
              fontSize: 16,
              lineHeight: 2,
              color: 'var(--color-text-primary)',
              fontFamily: 'var(--font-body)',
            }}
            className="content-section"
          >
            <MathText text={section.content} />
          </div>
        </section>
      ))}

      <style>{`
        .content-section table {
          width: 100%;
          border-collapse: collapse;
          margin: 16px 0;
          font-size: 14px;
        }
        .content-section th,
        .content-section td {
          padding: 10px 12px;
          border: 1px solid var(--color-border);
          text-align: left;
        }
        .content-section th {
          background: var(--color-surface-2);
          font-family: var(--font-heading);
          font-weight: 600;
        }
        .content-section code {
          background: var(--color-surface-2);
          padding: 2px 6px;
          border-radius: 4px;
          font-family: var(--font-mono);
          font-size: 0.9em;
        }
        .content-section pre {
          background: #1e1e1e;
          color: #d4d4d4;
          padding: 16px 20px;
          border-radius: var(--radius-md);
          overflow-x: auto;
          font-family: var(--font-mono);
          font-size: 13px;
          line-height: 1.6;
        }
        .content-section pre code {
          background: none;
          padding: 0;
        }
        .content-section ul,
        .content-section ol {
          padding-left: 24px;
          margin: 12px 0;
        }
        .content-section li {
          margin: 8px 0;
        }
        .content-section hr {
          border: none;
          border-top: 1px solid var(--color-border-faint);
          margin: 32px 0;
        }
      `}</style>
    </div>
  );
}
