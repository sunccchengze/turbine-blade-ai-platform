import type { Question } from '../data/questions';
import { CheckCircle, BookOpen, PenLine, MessageSquare, FileText, BookMarked } from 'lucide-react';

interface SidebarProps {
  mode: 'content' | 'questions';
  onModeChange: (mode: 'content' | 'questions') => void;
  sections: string[];
  activeSection: string;
  onSectionChange: (section: string) => void;
  questions: Question[];
  activeIndex: number;
  onQuestionSelect: (index: number) => void;
  mastered: Set<string>;
  totalQuestions: number;
  totalMastered: number;
  getSectionTitle: (id: string) => string;
}

const typeIcons: Record<string, typeof BookOpen> = {
  choice: BookOpen,
  fill: PenLine,
  short: MessageSquare,
};

export default function Sidebar({
  mode,
  onModeChange,
  sections,
  activeSection,
  onSectionChange,
  questions,
  activeIndex,
  onQuestionSelect,
  mastered,
  totalQuestions,
  totalMastered,
  getSectionTitle,
}: SidebarProps) {
  const progress = totalQuestions > 0 ? (totalMastered / totalQuestions) * 100 : 0;

  return (
    <aside
      style={{
        width: 280,
        minWidth: 280,
        height: '100vh',
        position: 'sticky',
        top: 0,
        background: 'var(--color-surface-1)',
        borderRight: '1px solid var(--color-border-faint)',
        display: 'flex',
        flexDirection: 'column',
        overflow: 'hidden',
      }}
    >
      {/* Logo */}
      <div
        style={{
          padding: '24px 20px 16px',
          borderBottom: '1px solid var(--color-border-faint)',
        }}
      >
        <h1
          style={{
            fontFamily: 'var(--font-heading)',
            fontSize: 16,
            fontWeight: 700,
            color: 'var(--color-text-primary)',
            margin: 0,
            letterSpacing: '-0.02em',
          }}
        >
          🚦 红线与证据等级
        </h1>
        <p
          style={{
            fontFamily: 'var(--font-heading)',
            fontSize: 12,
            color: 'var(--color-text-muted)',
            margin: '4px 0 0',
          }}
        >
          第 1 单元 · 交互式学习
        </p>

        {/* Progress bar */}
        <div style={{ marginTop: 14 }}>
          <div
            style={{
              display: 'flex',
              justifyContent: 'space-between',
              fontSize: 12,
              fontFamily: 'var(--font-heading)',
              color: 'var(--color-text-muted)',
              marginBottom: 6,
            }}
          >
            <span>掌握进度</span>
            <span>
              {totalMastered}/{totalQuestions}
            </span>
          </div>
          <div
            style={{
              height: 6,
              borderRadius: 'var(--radius-full)',
              background: 'var(--color-surface-2)',
              overflow: 'hidden',
            }}
          >
            <div
              style={{
                height: '100%',
                width: `${progress}%`,
                borderRadius: 'var(--radius-full)',
                background: 'var(--color-success)',
                transition: 'width 400ms cubic-bezier(0.4, 0, 0.2, 1)',
              }}
            />
          </div>
        </div>
      </div>

      {/* Mode tabs */}
      <div
        style={{
          padding: '12px',
          display: 'flex',
          gap: 8,
          borderBottom: '1px solid var(--color-border-faint)',
        }}
      >
        <button
          onClick={() => onModeChange('content')}
          style={{
            flex: 1,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            gap: 6,
            padding: '8px 12px',
            borderRadius: 'var(--radius-md)',
            border: mode === 'content'
              ? '1px solid var(--color-primary)'
              : '1px solid var(--color-border)',
            background: mode === 'content'
              ? 'var(--color-primary-soft)'
              : 'transparent',
            color: mode === 'content'
              ? 'var(--color-primary-dark)'
              : 'var(--color-text-muted)',
            fontSize: 13,
            fontFamily: 'var(--font-heading)',
            fontWeight: 500,
            cursor: 'pointer',
          }}
        >
          <FileText size={14} />
          教材
        </button>
        <button
          onClick={() => onModeChange('questions')}
          style={{
            flex: 1,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            gap: 6,
            padding: '8px 12px',
            borderRadius: 'var(--radius-md)',
            border: mode === 'questions'
              ? '1px solid var(--color-primary)'
              : '1px solid var(--color-border)',
            background: mode === 'questions'
              ? 'var(--color-primary-soft)'
              : 'transparent',
            color: mode === 'questions'
              ? 'var(--color-primary-dark)'
              : 'var(--color-text-muted)',
            fontSize: 13,
            fontFamily: 'var(--font-heading)',
            fontWeight: 500,
            cursor: 'pointer',
          }}
        >
          <BookMarked size={14} />
          练习
        </button>
      </div>

      {/* Section tabs */}
      {mode === 'questions' && (
        <div
          style={{
            padding: '10px 12px 6px',
            display: 'flex',
            flexWrap: 'wrap',
            gap: 6,
          }}
        >
          {sections.map((section, i) => (
            <button
              key={section}
              onClick={() => onSectionChange(section)}
              style={{
                padding: '5px 10px',
                borderRadius: 'var(--radius-full)',
                border:
                  activeSection === section
                    ? '1px solid var(--color-primary)'
                    : '1px solid var(--color-border)',
                background:
                  activeSection === section
                    ? 'var(--color-primary-soft)'
                    : 'transparent',
                color:
                  activeSection === section
                    ? 'var(--color-primary-dark)'
                    : 'var(--color-text-muted)',
                fontSize: 12,
                fontFamily: 'var(--font-heading)',
                fontWeight: 500,
                cursor: 'pointer',
                transition: 'all 200ms ease',
              }}
            >
              <kbd
                style={{
                  fontSize: 10,
                  fontFamily: 'var(--font-mono)',
                  marginRight: 3,
                  opacity: 0.6,
                }}
              >
                {i + 1}
              </kbd>
              {getSectionTitle(section)}
            </button>
          ))}
        </div>
      )}

      {/* Questions list */}
      {mode === 'questions' && (
        <div
          style={{
            flex: 1,
            overflowY: 'auto',
            padding: '8px 12px 20px',
          }}
        >
          {questions.map((q, i) => {
            const Icon = typeIcons[q.type] || BookOpen;
            const isMastered = mastered.has(q.id);
            const isActive = i === activeIndex;

            return (
              <button
                key={q.id}
                onClick={() => onQuestionSelect(i)}
                style={{
                  width: '100%',
                  display: 'flex',
                  alignItems: 'center',
                  gap: 8,
                  padding: '8px 10px',
                  marginBottom: 2,
                  borderRadius: 'var(--radius-md)',
                  border: 'none',
                  background: isActive
                    ? 'var(--color-primary-soft)'
                    : 'transparent',
                  cursor: 'pointer',
                  textAlign: 'left',
                  transition: 'all 150ms ease',
                }}
              >
                <Icon
                  size={14}
                  strokeWidth={1.5}
                  color={
                    isActive
                      ? 'var(--color-primary-dark)'
                      : 'var(--color-text-faint)'
                  }
                />
                <span
                  style={{
                    flex: 1,
                    fontSize: 13,
                    fontFamily: 'var(--font-mono)',
                    color: isActive
                      ? 'var(--color-primary-dark)'
                      : 'var(--color-text-primary)',
                    fontWeight: isActive ? 500 : 400,
                    overflow: 'hidden',
                    textOverflow: 'ellipsis',
                    whiteSpace: 'nowrap',
                  }}
                >
                  {q.number}
                </span>
                {isMastered && (
                  <CheckCircle
                    size={14}
                    color="var(--color-success)"
                    strokeWidth={2}
                  />
                )}
              </button>
            );
          })}
        </div>
      )}

      {/* Content sections */}
      {mode === 'content' && (
        <div
          style={{
            flex: 1,
            overflowY: 'auto',
            padding: '12px',
          }}
        >
          <a
            href="#section-intro"
            style={{
              display: 'block',
              padding: '10px 12px',
              marginBottom: 4,
              borderRadius: 'var(--radius-md)',
              fontSize: 14,
              fontFamily: 'var(--font-heading)',
              color: 'var(--color-text-primary)',
              textDecoration: 'none',
              background: 'transparent',
            }}
          >
            📌 单元导言
          </a>
          <a
            href="#section-1-1"
            style={{
              display: 'block',
              padding: '10px 12px',
              marginBottom: 4,
              borderRadius: 'var(--radius-md)',
              fontSize: 14,
              fontFamily: 'var(--font-heading)',
              color: 'var(--color-text-primary)',
              textDecoration: 'none',
            }}
          >
            1.1 五档说法
          </a>
          <a
            href="#section-1-2"
            style={{
              display: 'block',
              padding: '10px 12px',
              marginBottom: 4,
              borderRadius: 'var(--radius-md)',
              fontSize: 14,
              fontFamily: 'var(--font-heading)',
              color: 'var(--color-text-primary)',
              textDecoration: 'none',
            }}
          >
            1.2 一句话怎么对档
          </a>
          <a
            href="#section-1-3"
            style={{
              display: 'block',
              padding: '10px 12px',
              marginBottom: 4,
              borderRadius: 'var(--radius-md)',
              fontSize: 14,
              fontFamily: 'var(--font-heading)',
              color: 'var(--color-text-primary)',
              textDecoration: 'none',
            }}
          >
            1.3 仓库地图
          </a>
        </div>
      )}

      {/* Footer */}
      <div
        style={{
          padding: '12px 16px',
          borderTop: '1px solid var(--color-border-faint)',
          fontSize: 12,
          color: 'var(--color-text-faint)',
          fontFamily: 'var(--font-heading)',
          display: 'flex',
          alignItems: 'center',
          gap: 6,
        }}
      >
        按
        <kbd
          style={{
            padding: '1px 5px',
            borderRadius: 3,
            background: 'var(--color-surface-2)',
            border: '1px solid var(--color-border)',
            fontSize: 11,
            fontFamily: 'var(--font-mono)',
          }}
        >
          ?
        </kbd>
        查看快捷键
      </div>
    </aside>
  );
}
