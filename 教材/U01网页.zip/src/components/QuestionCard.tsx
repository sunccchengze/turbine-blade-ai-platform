import { useState, useEffect } from 'react';
import type { Question } from '../data/questions';
import MathText from './MathText';
import { ChevronDown, ChevronUp, CheckCircle, XCircle, BookOpen, PenLine, MessageSquare } from 'lucide-react';

interface QuestionCardProps {
  question: Question;
  index: number;
  isActive: boolean;
  showAnswer: boolean;
  onToggleAnswer: () => void;
  mastered: boolean;
  onToggleMastered: () => void;
}

const typeConfig = {
  choice: { label: '选择', icon: BookOpen, color: '#6A9BCC' },
  fill: { label: '填空', icon: PenLine, color: '#C9973B' },
  short: { label: '简答', icon: MessageSquare, color: '#6A8C5F' },
};

const difficultyConfig = {
  easy: { label: '易', color: '#6A8C5F', bg: '#6A8C5F18' },
  medium: { label: '中', color: '#C9973B', bg: '#C9973B18' },
  hard: { label: '难', color: '#B84A3A', bg: '#B84A3A18' },
};

export default function QuestionCard({
  question,
  index,
  isActive,
  showAnswer,
  onToggleAnswer,
  mastered,
  onToggleMastered,
}: QuestionCardProps) {
  const [animateIn, setAnimateIn] = useState(false);
  const config = typeConfig[question.type];
  const diffConfig = difficultyConfig[question.difficulty];
  const Icon = config.icon;

  useEffect(() => {
    if (isActive) {
      setAnimateIn(true);
    }
  }, [isActive]);

  return (
    <div
      id={`question-${question.id}`}
      style={{
        background: isActive ? 'var(--color-surface-1)' : 'var(--color-surface-1)',
        border: isActive
          ? '2px solid var(--color-primary)'
          : '1px solid var(--color-border-faint)',
        borderRadius: 'var(--radius-lg)',
        boxShadow: isActive ? 'var(--shadow-md)' : 'var(--shadow-sm)',
        padding: '24px 28px',
        transition: 'all 250ms cubic-bezier(0.4, 0, 0.2, 1)',
        opacity: animateIn ? 1 : 0.7,
        transform: animateIn ? 'translateY(0)' : 'translateY(4px)',
        position: 'relative',
        overflow: 'hidden',
      }}
    >
      {/* Mastered overlay */}
      {mastered && (
        <div
          style={{
            position: 'absolute',
            top: 12,
            right: 12,
            display: 'flex',
            alignItems: 'center',
            gap: 4,
            color: 'var(--color-success)',
            fontSize: 13,
            fontFamily: 'var(--font-heading)',
            fontWeight: 500,
          }}
        >
          <CheckCircle size={16} />
          已掌握
        </div>
      )}

      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 14, flexWrap: 'wrap' }}>
        <span
          style={{
            fontSize: 14,
            fontFamily: 'var(--font-mono)',
            color: 'var(--color-text-muted)',
            fontWeight: 500,
          }}
        >
          {question.id}
        </span>
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: 5,
            background: `${config.color}18`,
            color: config.color,
            padding: '3px 10px',
            borderRadius: 'var(--radius-full)',
            fontSize: 12,
            fontFamily: 'var(--font-heading)',
            fontWeight: 500,
          }}
        >
          <Icon size={13} strokeWidth={1.5} />
          {config.label}
        </div>
        <div
          style={{
            background: diffConfig.bg,
            color: diffConfig.color,
            padding: '3px 10px',
            borderRadius: 'var(--radius-full)',
            fontSize: 12,
            fontFamily: 'var(--font-heading)',
            fontWeight: 500,
          }}
        >
          {diffConfig.label}
        </div>
        <span
          style={{
            fontSize: 13,
            color: 'var(--color-text-faint)',
            fontFamily: 'var(--font-heading)',
            marginLeft: 'auto',
            paddingRight: mastered ? 80 : 0,
          }}
        >
          #{index + 1}
        </span>
      </div>

      {/* Stem */}
      <div
        style={{
          fontSize: 16,
          lineHeight: 1.9,
          color: 'var(--color-text-primary)',
          fontFamily: 'var(--font-body)',
          marginBottom: 12,
        }}
      >
        <MathText text={question.stem} />
      </div>

      {/* Options for choice questions */}
      {question.options && (
        <div
          style={{
            display: 'flex',
            flexDirection: 'column',
            gap: 8,
            marginBottom: 16,
            paddingLeft: 4,
          }}
        >
          {question.options.map((opt, i) => {
            const letter = opt.charAt(0);
            const isCorrect = showAnswer && letter === question.answer;
            return (
              <div
                key={i}
                style={{
                  padding: '8px 14px',
                  borderRadius: 'var(--radius-md)',
                  background: isCorrect ? '#6A8C5F15' : 'transparent',
                  border: isCorrect
                    ? '1px solid var(--color-success)'
                    : '1px solid transparent',
                  fontSize: 15,
                  fontFamily: 'var(--font-body)',
                  color: 'var(--color-text-primary)',
                  transition: 'all 200ms ease',
                }}
              >
                <MathText text={opt} />
              </div>
            );
          })}
        </div>
      )}

      {/* Answer & Analysis toggle */}
      <div style={{ display: 'flex', gap: 8, marginTop: 12, flexWrap: 'wrap' }}>
        <button
          onClick={onToggleAnswer}
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: 6,
            padding: '8px 16px',
            borderRadius: 'var(--radius-md)',
            border: '1px solid var(--color-border)',
            background: showAnswer ? 'var(--color-primary-soft)' : 'transparent',
            color: showAnswer ? 'var(--color-primary-dark)' : 'var(--color-text-muted)',
            fontSize: 14,
            fontFamily: 'var(--font-heading)',
            fontWeight: 500,
            cursor: 'pointer',
            transition: 'all 200ms ease',
          }}
        >
          {showAnswer ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
          {showAnswer ? '收起答案' : '显示答案'}
          <kbd
            style={{
              fontSize: 11,
              padding: '1px 5px',
              borderRadius: 3,
              background: 'var(--color-surface-2)',
              border: '1px solid var(--color-border)',
              color: 'var(--color-text-faint)',
              fontFamily: 'var(--font-mono)',
              marginLeft: 4,
            }}
          >
            Space
          </kbd>
        </button>

        <button
          onClick={onToggleMastered}
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: 6,
            padding: '8px 16px',
            borderRadius: 'var(--radius-md)',
            border: mastered
              ? '1px solid var(--color-success)'
              : '1px solid var(--color-border)',
            background: mastered ? '#6A8C5F15' : 'transparent',
            color: mastered ? 'var(--color-success)' : 'var(--color-text-muted)',
            fontSize: 14,
            fontFamily: 'var(--font-heading)',
            fontWeight: 500,
            cursor: 'pointer',
            transition: 'all 200ms ease',
          }}
        >
          {mastered ? <CheckCircle size={16} /> : <XCircle size={16} />}
          {mastered ? '已掌握' : '标记掌握'}
          <kbd
            style={{
              fontSize: 11,
              padding: '1px 5px',
              borderRadius: 3,
              background: 'var(--color-surface-2)',
              border: '1px solid var(--color-border)',
              color: 'var(--color-text-faint)',
              fontFamily: 'var(--font-mono)',
              marginLeft: 4,
            }}
          >
            M
          </kbd>
        </button>
      </div>

      {/* Answer */}
      {showAnswer && (
        <div
          style={{
            marginTop: 16,
            padding: '20px 24px',
            background: 'var(--color-surface-2)',
            borderRadius: 'var(--radius-md)',
            borderLeft: '3px solid var(--color-primary)',
          }}
        >
          <div
            style={{
              fontFamily: 'var(--font-heading)',
              fontSize: 14,
              fontWeight: 600,
              color: 'var(--color-primary-dark)',
              marginBottom: 10,
              display: 'flex',
              alignItems: 'center',
              gap: 8,
              flexWrap: 'wrap',
            }}
          >
            📖 答案
            {question.type === 'choice' && (
              <span
                style={{
                  background: 'var(--color-success)',
                  color: 'white',
                  padding: '2px 10px',
                  borderRadius: 'var(--radius-full)',
                  fontSize: 13,
                }}
              >
                {question.answer}
              </span>
            )}
            {question.type === 'fill' && (
              <span
                style={{
                  fontSize: 14,
                  color: 'var(--color-success)',
                  fontWeight: 600,
                  fontFamily: 'var(--font-body)',
                }}
              >
                <MathText text={question.answer} />
              </span>
            )}
          </div>
          {question.type === 'short' && (
            <div
              style={{
                fontSize: 15,
                lineHeight: 1.9,
                color: 'var(--color-text-primary)',
                fontFamily: 'var(--font-body)',
                marginBottom: question.explanation ? 12 : 0,
                padding: '12px 16px',
                background: 'var(--color-surface-1)',
                borderRadius: 'var(--radius-md)',
                border: '1px solid var(--color-border-faint)',
              }}
            >
              <MathText text={question.answer} />
            </div>
          )}
          {question.explanation && (
            <div
              style={{
                fontSize: 14,
                lineHeight: 1.8,
                color: 'var(--color-text-muted)',
                fontFamily: 'var(--font-body)',
                marginTop: 8,
              }}
            >
              <MathText text={`💡 ${question.explanation}`} />
            </div>
          )}
        </div>
      )}
    </div>
  );
}
