import { useState, useEffect, useCallback, useRef } from 'react';
import { questions, getSections, getSectionTitle, getQuestionsBySection } from './data/questions';
import QuestionCard from './components/QuestionCard';
import Sidebar from './components/Sidebar';
import KeyboardHelp from './components/KeyboardHelp';
import ContentViewer from './components/ContentViewer';
import {
  ChevronUp,
  ChevronDown,
  Eye,
  EyeOff,
  Filter,
  FilterX,
  Keyboard,
} from 'lucide-react';

const STORAGE_KEY = 'evidence-grade-mastered';
const SECTION_KEY = 'evidence-grade-section';
const MODE_KEY = 'evidence-grade-mode';
const VISITED_KEY = 'evidence-grade-visited';

function loadMastered(): Set<string> {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) return new Set(JSON.parse(raw));
  } catch {
    // ignore
  }
  return new Set();
}

function saveMastered(mastered: Set<string>) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify([...mastered]));
}

export default function App() {
  const allSections = getSections();
  const [mode, setMode] = useState<'content' | 'questions'>(() => {
    const saved = localStorage.getItem(MODE_KEY);
    return saved === 'content' ? 'content' : 'questions';
  });
  const [activeSection, setActiveSection] = useState(() => {
    const saved = localStorage.getItem(SECTION_KEY);
    return saved && allSections.includes(saved) ? saved : allSections[0];
  });
  const [activeIndex, setActiveIndex] = useState(0);
  const [showAnswers, setShowAnswers] = useState<Set<string>>(new Set());
  const [mastered, setMastered] = useState<Set<string>>(loadMastered);
  const [showHelp, setShowHelp] = useState(() => {
    const visited = localStorage.getItem(VISITED_KEY);
    if (!visited) {
      localStorage.setItem(VISITED_KEY, 'true');
      return true;
    }
    return false;
  });
  const [hideMode, setHideMode] = useState(false);
  const [showAllAnalysis, setShowAllAnalysis] = useState(false);
  const [toast, setToast] = useState<string | null>(null);
  const toastTimer = useRef<ReturnType<typeof setTimeout>>(undefined);

  const currentQuestions = getQuestionsBySection(activeSection).filter(q =>
    hideMode ? !mastered.has(q.id) : true
  );

  const currentQuestion = currentQuestions[activeIndex];

  // Save mastered state
  useEffect(() => {
    saveMastered(mastered);
  }, [mastered]);

  // Save active section
  useEffect(() => {
    localStorage.setItem(SECTION_KEY, activeSection);
  }, [activeSection]);

  // Save mode
  useEffect(() => {
    localStorage.setItem(MODE_KEY, mode);
  }, [mode]);

  // Show toast
  const showToast = useCallback((msg: string) => {
    setToast(msg);
    if (toastTimer.current) clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(null), 1500);
  }, []);

  // Scroll to active question
  const scrollToQuestion = useCallback((id: string) => {
    const el = document.getElementById(`question-${id}`);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  }, []);

  // Change section
  const changeSection = useCallback(
    (section: string) => {
      setActiveSection(section);
      setActiveIndex(0);
      setShowAnswers(new Set());
      setShowAllAnalysis(false);
      showToast(`📚 ${getSectionTitle(section)}`);
    },
    [showToast]
  );

  // Toggle answer for current question
  const toggleAnswer = useCallback(
    (id: string) => {
      setShowAnswers(prev => {
        const next = new Set(prev);
        if (next.has(id)) {
          next.delete(id);
        } else {
          next.add(id);
        }
        return next;
      });
    },
    []
  );

  // Toggle mastered
  const toggleMastered = useCallback(
    (id: string) => {
      setMastered(prev => {
        const next = new Set(prev);
        if (next.has(id)) {
          next.delete(id);
          showToast('📌 取消掌握标记');
        } else {
          next.add(id);
          showToast('✅ 已标记为掌握');
        }
        return next;
      });
    },
    [showToast]
  );

  // Keyboard handler
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      // Don't handle if focused on input
      if (
        e.target instanceof HTMLInputElement ||
        e.target instanceof HTMLTextAreaElement
      ) {
        return;
      }

      const key = e.key.toLowerCase();

      if (key === '?') {
        e.preventDefault();
        setShowHelp(prev => !prev);
        return;
      }

      if (key === 'escape') {
        setShowHelp(false);
        return;
      }

      // Tab: switch mode
      if (key === 'tab') {
        e.preventDefault();
        setMode(prev => {
          const next = prev === 'content' ? 'questions' : 'content';
          showToast(next === 'content' ? '📖 教材模式' : '✏️ 练习模式');
          return next;
        });
        return;
      }

      // Only process question-related keys in questions mode
      if (mode !== 'questions') return;

      // Section switching: 1-4
      if (['1', '2', '3', '4'].includes(key) && !e.ctrlKey && !e.metaKey) {
        const idx = parseInt(key) - 1;
        if (idx < allSections.length) {
          e.preventDefault();
          changeSection(allSections[idx]);
        }
        return;
      }

      // Navigate: up/k, down/j
      if (key === 'arrowup' || key === 'k') {
        e.preventDefault();
        setActiveIndex(prev => {
          const next = Math.max(0, prev - 1);
          if (currentQuestions[next]) {
            setTimeout(() => scrollToQuestion(currentQuestions[next].id), 50);
          }
          return next;
        });
        return;
      }

      if (key === 'arrowdown' || key === 'j') {
        e.preventDefault();
        setActiveIndex(prev => {
          const next = Math.min(currentQuestions.length - 1, prev + 1);
          if (currentQuestions[next]) {
            setTimeout(() => scrollToQuestion(currentQuestions[next].id), 50);
          }
          return next;
        });
        return;
      }

      if (key === 'home') {
        e.preventDefault();
        setActiveIndex(0);
        if (currentQuestions[0]) {
          setTimeout(() => scrollToQuestion(currentQuestions[0].id), 50);
        }
        return;
      }

      if (key === 'end') {
        e.preventDefault();
        const last = currentQuestions.length - 1;
        setActiveIndex(last);
        if (currentQuestions[last]) {
          setTimeout(() => scrollToQuestion(currentQuestions[last].id), 50);
        }
        return;
      }

      // Space: toggle answer
      if (key === ' ') {
        e.preventDefault();
        if (currentQuestion) {
          toggleAnswer(currentQuestion.id);
        }
        return;
      }

      // M: toggle mastered
      if (key === 'm') {
        e.preventDefault();
        if (currentQuestion) {
          toggleMastered(currentQuestion.id);
        }
        return;
      }

      // A: toggle all analysis
      if (key === 'a') {
        e.preventDefault();
        setShowAllAnalysis(prev => {
          const next = !prev;
          if (next) {
            setShowAnswers(new Set(currentQuestions.map(q => q.id)));
            showToast('📖 展开所有答案');
          } else {
            setShowAnswers(new Set());
            showToast('📕 收起所有答案');
          }
          return next;
        });
        return;
      }

      // H: hide mastered
      if (key === 'h') {
        e.preventDefault();
        setHideMode(prev => {
          const next = !prev;
          setActiveIndex(0);
          showToast(next ? '🔍 只显示未掌握' : '📋 显示全部');
          return next;
        });
        return;
      }

      // R: reset progress
      if (key === 'r' && !e.ctrlKey && !e.metaKey) {
        e.preventDefault();
        if (confirm('确定要重置所有学习进度吗？')) {
          setMastered(new Set());
          showToast('🔄 已重置进度');
        }
        return;
      }
    };

    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [
    mode,
    currentQuestions,
    currentQuestion,
    allSections,
    changeSection,
    toggleAnswer,
    toggleMastered,
    scrollToQuestion,
    showToast,
  ]);

  const totalMastered = [...mastered].filter(id =>
    questions.some(q => q.id === id)
  ).length;

  return (
    <div
      style={{
        display: 'flex',
        minHeight: '100vh',
        background: 'var(--color-bg)',
      }}
    >
      {/* Sidebar */}
      <Sidebar
        mode={mode}
        onModeChange={(m) => {
          setMode(m);
          showToast(m === 'content' ? '📖 教材模式' : '✏️ 练习模式');
        }}
        sections={allSections}
        activeSection={activeSection}
        onSectionChange={changeSection}
        questions={currentQuestions}
        activeIndex={activeIndex}
        onQuestionSelect={i => {
          setActiveIndex(i);
          if (currentQuestions[i]) {
            setTimeout(() => scrollToQuestion(currentQuestions[i].id), 50);
          }
        }}
        mastered={mastered}
        totalQuestions={questions.length}
        totalMastered={totalMastered}
        getSectionTitle={getSectionTitle}
      />

      {/* Main content */}
      <main
        style={{
          flex: 1,
          padding: '32px 48px 80px',
          maxWidth: 900,
          margin: '0 auto',
          overflowY: 'auto',
        }}
      >
        {mode === 'content' ? (
          <ContentViewer />
        ) : (
          <>
            {/* Header */}
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                marginBottom: 32,
                flexWrap: 'wrap',
                gap: 16,
              }}
            >
              <div>
                <h2
                  style={{
                    fontFamily: 'var(--font-heading)',
                    fontSize: 28,
                    fontWeight: 600,
                    color: 'var(--color-text-primary)',
                    margin: 0,
                    letterSpacing: '-0.02em',
                  }}
                >
                  {getSectionTitle(activeSection)}
                </h2>
                <p
                  style={{
                    fontFamily: 'var(--font-body)',
                    fontSize: 15,
                    color: 'var(--color-text-muted)',
                    margin: '4px 0 0',
                  }}
                >
                  共 {currentQuestions.length} 题
                  {hideMode && (
                    <span style={{ color: 'var(--color-warning)' }}>
                      {' '}
                      · 筛选模式：仅未掌握
                    </span>
                  )}
                </p>
              </div>

              {/* Toolbar */}
              <div style={{ display: 'flex', gap: 8 }}>
                <button
                  onClick={() => {
                    setHideMode(prev => !prev);
                    setActiveIndex(0);
                    showToast(hideMode ? '📋 显示全部' : '🔍 只显示未掌握');
                  }}
                  title="筛选未掌握 (H)"
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: 4,
                    padding: '8px 12px',
                    borderRadius: 'var(--radius-md)',
                    border: hideMode
                      ? '1px solid var(--color-warning)'
                      : '1px solid var(--color-border)',
                    background: hideMode ? '#C9973B15' : 'transparent',
                    color: hideMode
                      ? 'var(--color-warning)'
                      : 'var(--color-text-muted)',
                    fontSize: 13,
                    fontFamily: 'var(--font-heading)',
                    fontWeight: 500,
                    cursor: 'pointer',
                  }}
                >
                  {hideMode ? <FilterX size={15} /> : <Filter size={15} />}
                </button>

                <button
                  onClick={() => {
                    const next = !showAllAnalysis;
                    setShowAllAnalysis(next);
                    if (next) {
                      setShowAnswers(new Set(currentQuestions.map(q => q.id)));
                      showToast('📖 展开所有答案');
                    } else {
                      setShowAnswers(new Set());
                      showToast('📕 收起所有答案');
                    }
                  }}
                  title="展开/收起所有答案 (A)"
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: 4,
                    padding: '8px 12px',
                    borderRadius: 'var(--radius-md)',
                    border: '1px solid var(--color-border)',
                    background: 'transparent',
                    color: 'var(--color-text-muted)',
                    fontSize: 13,
                    fontFamily: 'var(--font-heading)',
                    fontWeight: 500,
                    cursor: 'pointer',
                  }}
                >
                  {showAllAnalysis ? <EyeOff size={15} /> : <Eye size={15} />}
                </button>

                <button
                  onClick={() => setShowHelp(true)}
                  title="快捷键帮助 (?)"
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: 4,
                    padding: '8px 12px',
                    borderRadius: 'var(--radius-md)',
                    border: '1px solid var(--color-border)',
                    background: 'transparent',
                    color: 'var(--color-text-muted)',
                    fontSize: 13,
                    fontFamily: 'var(--font-heading)',
                    fontWeight: 500,
                    cursor: 'pointer',
                  }}
                >
                  <Keyboard size={15} />
                </button>
              </div>
            </div>

            {/* Questions */}
            {currentQuestions.length === 0 ? (
              <div
                style={{
                  textAlign: 'center',
                  padding: '80px 20px',
                  color: 'var(--color-text-muted)',
                }}
              >
                <div style={{ fontSize: 48, marginBottom: 16 }}>🎉</div>
                <h3
                  style={{
                    fontFamily: 'var(--font-heading)',
                    fontSize: 22,
                    fontWeight: 600,
                    margin: '0 0 8px',
                  }}
                >
                  本节所有题目都已掌握！
                </h3>
                <p
                  style={{
                    fontFamily: 'var(--font-body)',
                    fontSize: 15,
                  }}
                >
                  按{' '}
                  <kbd
                    style={{
                      padding: '2px 6px',
                      borderRadius: 3,
                      background: 'var(--color-surface-2)',
                      border: '1px solid var(--color-border)',
                      fontFamily: 'var(--font-mono)',
                      fontSize: 12,
                    }}
                  >
                    H
                  </kbd>{' '}
                  查看全部题目，或按{' '}
                  <kbd
                    style={{
                      padding: '2px 6px',
                      borderRadius: 3,
                      background: 'var(--color-surface-2)',
                      border: '1px solid var(--color-border)',
                      fontFamily: 'var(--font-mono)',
                      fontSize: 12,
                    }}
                  >
                    R
                  </kbd>{' '}
                  重置进度
                </p>
              </div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
                {currentQuestions.map((q, i) => (
                  <QuestionCard
                    key={q.id}
                    question={q}
                    index={i}
                    isActive={i === activeIndex}
                    showAnswer={showAnswers.has(q.id)}
                    onToggleAnswer={() => toggleAnswer(q.id)}
                    mastered={mastered.has(q.id)}
                    onToggleMastered={() => toggleMastered(q.id)}
                  />
                ))}
              </div>
            )}
          </>
        )}
      </main>

      {/* Floating nav - only show in questions mode */}
      {mode === 'questions' && currentQuestions.length > 0 && (
        <div
          style={{
            position: 'fixed',
            bottom: 24,
            right: 24,
            display: 'flex',
            flexDirection: 'column',
            gap: 8,
            zIndex: 50,
          }}
        >
          <button
            onClick={() => {
              const prev = Math.max(0, activeIndex - 1);
              setActiveIndex(prev);
              if (currentQuestions[prev]) {
                scrollToQuestion(currentQuestions[prev].id);
              }
            }}
            disabled={activeIndex <= 0}
            style={{
              width: 44,
              height: 44,
              borderRadius: 'var(--radius-lg)',
              border: '1px solid var(--color-border)',
              background: 'var(--color-surface-1)',
              boxShadow: 'var(--shadow-sm)',
              cursor: activeIndex <= 0 ? 'not-allowed' : 'pointer',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color:
                activeIndex <= 0
                  ? 'var(--color-text-faint)'
                  : 'var(--color-text-muted)',
              opacity: activeIndex <= 0 ? 0.5 : 1,
            }}
          >
            <ChevronUp size={20} />
          </button>

          <div
            style={{
              width: 44,
              height: 44,
              borderRadius: 'var(--radius-lg)',
              background: 'var(--color-primary)',
              color: 'white',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontSize: 14,
              fontFamily: 'var(--font-heading)',
              fontWeight: 600,
              boxShadow: 'var(--shadow-md)',
            }}
          >
            {activeIndex + 1}
          </div>

          <button
            onClick={() => {
              const next = Math.min(currentQuestions.length - 1, activeIndex + 1);
              setActiveIndex(next);
              if (currentQuestions[next]) {
                scrollToQuestion(currentQuestions[next].id);
              }
            }}
            disabled={activeIndex >= currentQuestions.length - 1}
            style={{
              width: 44,
              height: 44,
              borderRadius: 'var(--radius-lg)',
              border: '1px solid var(--color-border)',
              background: 'var(--color-surface-1)',
              boxShadow: 'var(--shadow-sm)',
              cursor:
                activeIndex >= currentQuestions.length - 1
                  ? 'not-allowed'
                  : 'pointer',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color:
                activeIndex >= currentQuestions.length - 1
                  ? 'var(--color-text-faint)'
                  : 'var(--color-text-muted)',
              opacity:
                activeIndex >= currentQuestions.length - 1 ? 0.5 : 1,
            }}
          >
            <ChevronDown size={20} />
          </button>
        </div>
      )}

      {/* Keyboard Help Modal */}
      <KeyboardHelp show={showHelp} onClose={() => setShowHelp(false)} />

      {/* Toast */}
      {toast && (
        <div
          style={{
            position: 'fixed',
            top: 24,
            left: '50%',
            transform: 'translateX(-50%)',
            padding: '10px 24px',
            borderRadius: 'var(--radius-full)',
            background: 'var(--color-text-primary)',
            color: 'var(--color-bg)',
            fontSize: 14,
            fontFamily: 'var(--font-heading)',
            fontWeight: 500,
            boxShadow: 'var(--shadow-lg)',
            zIndex: 200,
            animation: 'toastIn 200ms ease',
          }}
        >
          {toast}
        </div>
      )}

      <style>{`
        @keyframes toastIn {
          from {
            opacity: 0;
            transform: translateX(-50%) translateY(-8px);
          }
          to {
            opacity: 1;
            transform: translateX(-50%) translateY(0);
          }
        }
      `}</style>
    </div>
  );
}
