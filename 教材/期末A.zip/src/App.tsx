import { useState, useEffect, useCallback, useRef } from 'react';
import { questions, examTitle, examInfo, getStats } from './data/questions';
import type { QuestionType, Difficulty } from './data/questions';
import QuestionCard from './components/QuestionCard';
import Sidebar from './components/Sidebar';
import KeyboardHelp from './components/KeyboardHelp';
import {
  ChevronUp,
  ChevronDown,
  Eye,
  EyeOff,
  Filter,
  FilterX,
  Keyboard,
} from 'lucide-react';

const STORAGE_KEY = 'exam-a-mastered';
const VISITED_KEY = 'exam-a-visited';

function loadMastered(): Set<string> {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) return new Set(JSON.parse(raw));
  } catch {
    // ignore
  }
  return new Set();
}

function saveMastered(mastered: Set<string>) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify([...mastered]));
}

export default function App() {
  const [activeIndex, setActiveIndex] = useState(0);
  const [showAnswers, setShowAnswers] = useState<Set<string>>(new Set());
  const [mastered, setMastered] = useState<Set<string>>(loadMastered);
  const [showHelp, setShowHelp] = useState(() => {
    const visited = localStorage.getItem(VISITED_KEY);
    if (!visited) {
      localStorage.setItem(VISITED_KEY, 'true');
      return true;
    }
    return false;
  });
  const [hideMode, setHideMode] = useState(false);
  const [showAllAnalysis, setShowAllAnalysis] = useState(false);
  const [filterType, setFilterType] = useState<QuestionType | 'all'>('all');
  const [filterDifficulty, setFilterDifficulty] = useState<Difficulty | 'all'>('all');
  const [toast, setToast] = useState<string | null>(null);
  const toastTimer = useRef<ReturnType<typeof setTimeout>>(undefined);

  // Filter questions
  const filteredQuestions = questions.filter(q => {
    if (hideMode && mastered.has(q.id)) return false;
    if (filterType !== 'all' && q.type !== filterType) return false;
    if (filterDifficulty !== 'all' && q.difficulty !== filterDifficulty) return false;
    return true;
  });

  const currentQuestion = filteredQuestions[activeIndex];
  const stats = getStats();

  // Save mastered state
  useEffect(() => {
    saveMastered(mastered);
  }, [mastered]);

  // Show toast
  const showToast = useCallback((msg: string) => {
    setToast(msg);
    if (toastTimer.current) clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(null), 1500);
  }, []);

  // Scroll to active question
  const scrollToQuestion = useCallback((id: string) => {
    const el = document.getElementById(`question-${id}`);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  }, []);

  // Toggle answer
  const toggleAnswer = useCallback((id: string) => {
    setShowAnswers(prev => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  }, []);

  // Toggle mastered
  const toggleMastered = useCallback(
    (id: string) => {
      setMastered(prev => {
        const next = new Set(prev);
        if (next.has(id)) {
          next.delete(id);
          showToast('📌 取消掌握标记');
        } else {
          next.add(id);
          showToast('✅ 已标记为掌握');
        }
        return next;
      });
    },
    [showToast]
  );

  // Keyboard handler
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (
        e.target instanceof HTMLInputElement ||
        e.target instanceof HTMLTextAreaElement
      ) {
        return;
      }

      const key = e.key.toLowerCase();

      if (key === '?') {
        e.preventDefault();
        setShowHelp(prev => !prev);
        return;
      }

      if (key === 'escape') {
        setShowHelp(false);
        return;
      }

      // Type filter shortcuts
      if (key === '0') {
        e.preventDefault();
        setFilterType('all');
        setActiveIndex(0);
        showToast('📋 显示全部题型');
        return;
      }
      if (key === '1') {
        e.preventDefault();
        setFilterType('choice');
        setActiveIndex(0);
        showToast('📝 选择题');
        return;
      }
      if (key === '2') {
        e.preventDefault();
        setFilterType('fill');
        setActiveIndex(0);
        showToast('✏️ 填空题');
        return;
      }
      if (key === '3') {
        e.preventDefault();
        setFilterType('short');
        setActiveIndex(0);
        showToast('💬 简答题');
        return;
      }

      // Navigate
      if (key === 'arrowup' || key === 'k') {
        e.preventDefault();
        setActiveIndex(prev => {
          const next = Math.max(0, prev - 1);
          if (filteredQuestions[next]) {
            setTimeout(() => scrollToQuestion(filteredQuestions[next].id), 50);
          }
          return next;
        });
        return;
      }

      if (key === 'arrowdown' || key === 'j') {
        e.preventDefault();
        setActiveIndex(prev => {
          const next = Math.min(filteredQuestions.length - 1, prev + 1);
          if (filteredQuestions[next]) {
            setTimeout(() => scrollToQuestion(filteredQuestions[next].id), 50);
          }
          return next;
        });
        return;
      }

      if (key === 'home') {
        e.preventDefault();
        setActiveIndex(0);
        if (filteredQuestions[0]) {
          setTimeout(() => scrollToQuestion(filteredQuestions[0].id), 50);
        }
        return;
      }

      if (key === 'end') {
        e.preventDefault();
        const last = filteredQuestions.length - 1;
        setActiveIndex(last);
        if (filteredQuestions[last]) {
          setTimeout(() => scrollToQuestion(filteredQuestions[last].id), 50);
        }
        return;
      }

      // Space: toggle answer
      if (key === ' ') {
        e.preventDefault();
        if (currentQuestion) {
          toggleAnswer(currentQuestion.id);
        }
        return;
      }

      // M: toggle mastered
      if (key === 'm') {
        e.preventDefault();
        if (currentQuestion) {
          toggleMastered(currentQuestion.id);
        }
        return;
      }

      // A: toggle all analysis
      if (key === 'a') {
        e.preventDefault();
        setShowAllAnalysis(prev => {
          const next = !prev;
          if (next) {
            setShowAnswers(new Set(filteredQuestions.map(q => q.id)));
            showToast('📖 展开所有答案');
          } else {
            setShowAnswers(new Set());
            showToast('📕 收起所有答案');
          }
          return next;
        });
        return;
      }

      // H: hide mastered
      if (key === 'h') {
        e.preventDefault();
        setHideMode(prev => {
          const next = !prev;
          setActiveIndex(0);
          showToast(next ? '🔍 只显示未掌握' : '📋 显示全部');
          return next;
        });
        return;
      }

      // R: reset progress
      if (key === 'r' && !e.ctrlKey && !e.metaKey) {
        e.preventDefault();
        if (confirm('确定要重置所有学习进度吗？')) {
          setMastered(new Set());
          showToast('🔄 已重置进度');
        }
        return;
      }
    };

    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [
    filteredQuestions,
    currentQuestion,
    toggleAnswer,
    toggleMastered,
    scrollToQuestion,
    showToast,
  ]);

  const totalMastered = [...mastered].filter(id =>
    questions.some(q => q.id === id)
  ).length;

  return (
    <div
      style={{
        display: 'flex',
        minHeight: '100vh',
        background: 'var(--color-bg)',
      }}
    >
      {/* Sidebar */}
      <Sidebar
        questions={filteredQuestions}
        activeIndex={activeIndex}
        onQuestionSelect={i => {
          setActiveIndex(i);
          if (filteredQuestions[i]) {
            setTimeout(() => scrollToQuestion(filteredQuestions[i].id), 50);
          }
        }}
        mastered={mastered}
        totalQuestions={questions.length}
        totalMastered={totalMastered}
        filterType={filterType}
        onFilterTypeChange={(t) => {
          setFilterType(t);
          setActiveIndex(0);
        }}
        filterDifficulty={filterDifficulty}
        onFilterDifficultyChange={(d) => {
          setFilterDifficulty(d);
          setActiveIndex(0);
        }}
      />

      {/* Main content */}
      <main
        style={{
          flex: 1,
          padding: '28px 44px 80px',
          maxWidth: 880,
          margin: '0 auto',
          overflowY: 'auto',
        }}
      >
        {/* Header */}
        <div
          style={{
            display: 'flex',
            alignItems: 'flex-start',
            justifyContent: 'space-between',
            marginBottom: 28,
            flexWrap: 'wrap',
            gap: 16,
          }}
        >
          <div>
            <h1
              style={{
                fontFamily: 'var(--font-heading)',
                fontSize: 26,
                fontWeight: 700,
                color: 'var(--color-text-primary)',
                margin: 0,
                letterSpacing: '-0.02em',
              }}
            >
              {examTitle}
            </h1>
            <p
              style={{
                fontFamily: 'var(--font-body)',
                fontSize: 14,
                color: 'var(--color-text-muted)',
                margin: '6px 0 0',
              }}
            >
              {examInfo}
            </p>
            <div
              style={{
                display: 'flex',
                gap: 12,
                marginTop: 10,
                fontSize: 12,
                fontFamily: 'var(--font-heading)',
              }}
            >
              <span style={{ color: '#6A9BCC' }}>选择 {stats.byType.choice}</span>
              <span style={{ color: '#C9973B' }}>填空 {stats.byType.fill}</span>
              <span style={{ color: '#6A8C5F' }}>简答 {stats.byType.short}</span>
              <span style={{ color: 'var(--color-text-faint)' }}>|</span>
              <span style={{ color: '#6A8C5F' }}>易 {stats.byDifficulty.easy}</span>
              <span style={{ color: '#C9973B' }}>中 {stats.byDifficulty.medium}</span>
              <span style={{ color: '#B84A3A' }}>难 {stats.byDifficulty.hard}</span>
            </div>
            {(filterType !== 'all' || filterDifficulty !== 'all' || hideMode) && (
              <p
                style={{
                  fontFamily: 'var(--font-heading)',
                  fontSize: 13,
                  color: 'var(--color-warning)',
                  margin: '8px 0 0',
                }}
              >
                筛选中：显示 {filteredQuestions.length} 题
              </p>
            )}
          </div>

          {/* Toolbar */}
          <div style={{ display: 'flex', gap: 6 }}>
            <button
              onClick={() => {
                setHideMode(prev => !prev);
                setActiveIndex(0);
                showToast(hideMode ? '📋 显示全部' : '🔍 只显示未掌握');
              }}
              title="筛选未掌握 (H)"
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: 4,
                padding: '7px 11px',
                borderRadius: 'var(--radius-md)',
                border: hideMode
                  ? '1px solid var(--color-warning)'
                  : '1px solid var(--color-border)',
                background: hideMode ? '#C9973B15' : 'transparent',
                color: hideMode
                  ? 'var(--color-warning)'
                  : 'var(--color-text-muted)',
                fontSize: 12,
                fontFamily: 'var(--font-heading)',
                fontWeight: 500,
                cursor: 'pointer',
              }}
            >
              {hideMode ? <FilterX size={14} /> : <Filter size={14} />}
            </button>

            <button
              onClick={() => {
                const next = !showAllAnalysis;
                setShowAllAnalysis(next);
                if (next) {
                  setShowAnswers(new Set(filteredQuestions.map(q => q.id)));
                  showToast('📖 展开所有答案');
                } else {
                  setShowAnswers(new Set());
                  showToast('📕 收起所有答案');
                }
              }}
              title="展开/收起所有答案 (A)"
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: 4,
                padding: '7px 11px',
                borderRadius: 'var(--radius-md)',
                border: '1px solid var(--color-border)',
                background: 'transparent',
                color: 'var(--color-text-muted)',
                fontSize: 12,
                fontFamily: 'var(--font-heading)',
                fontWeight: 500,
                cursor: 'pointer',
              }}
            >
              {showAllAnalysis ? <EyeOff size={14} /> : <Eye size={14} />}
            </button>

            <button
              onClick={() => setShowHelp(true)}
              title="快捷键帮助 (?)"
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: 4,
                padding: '7px 11px',
                borderRadius: 'var(--radius-md)',
                border: '1px solid var(--color-border)',
                background: 'transparent',
                color: 'var(--color-text-muted)',
                fontSize: 12,
                fontFamily: 'var(--font-heading)',
                fontWeight: 500,
                cursor: 'pointer',
              }}
            >
              <Keyboard size={14} />
            </button>
          </div>
        </div>

        {/* Questions */}
        {filteredQuestions.length === 0 ? (
          <div
            style={{
              textAlign: 'center',
              padding: '70px 20px',
              color: 'var(--color-text-muted)',
            }}
          >
            <div style={{ fontSize: 44, marginBottom: 14 }}>🎉</div>
            <h3
              style={{
                fontFamily: 'var(--font-heading)',
                fontSize: 20,
                fontWeight: 600,
                margin: '0 0 8px',
              }}
            >
              {hideMode ? '所有题目都已掌握！' : '没有符合筛选条件的题目'}
            </h3>
            <p
              style={{
                fontFamily: 'var(--font-body)',
                fontSize: 14,
              }}
            >
              按{' '}
              <kbd
                style={{
                  padding: '2px 5px',
                  borderRadius: 3,
                  background: 'var(--color-surface-2)',
                  border: '1px solid var(--color-border)',
                  fontFamily: 'var(--font-mono)',
                  fontSize: 11,
                }}
              >
                H
              </kbd>{' '}
              或{' '}
              <kbd
                style={{
                  padding: '2px 5px',
                  borderRadius: 3,
                  background: 'var(--color-surface-2)',
                  border: '1px solid var(--color-border)',
                  fontFamily: 'var(--font-mono)',
                  fontSize: 11,
                }}
              >
                0
              </kbd>{' '}
              查看全部
            </p>
          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
            {filteredQuestions.map((q, i) => (
              <QuestionCard
                key={q.id}
                question={q}
                index={i}
                isActive={i === activeIndex}
                showAnswer={showAnswers.has(q.id)}
                onToggleAnswer={() => toggleAnswer(q.id)}
                mastered={mastered.has(q.id)}
                onToggleMastered={() => toggleMastered(q.id)}
              />
            ))}
          </div>
        )}
      </main>

      {/* Floating nav */}
      {filteredQuestions.length > 0 && (
        <div
          style={{
            position: 'fixed',
            bottom: 22,
            right: 22,
            display: 'flex',
            flexDirection: 'column',
            gap: 6,
            zIndex: 50,
          }}
        >
          <button
            onClick={() => {
              const prev = Math.max(0, activeIndex - 1);
              setActiveIndex(prev);
              if (filteredQuestions[prev]) {
                scrollToQuestion(filteredQuestions[prev].id);
              }
            }}
            disabled={activeIndex <= 0}
            style={{
              width: 40,
              height: 40,
              borderRadius: 'var(--radius-lg)',
              border: '1px solid var(--color-border)',
              background: 'var(--color-surface-1)',
              boxShadow: 'var(--shadow-sm)',
              cursor: activeIndex <= 0 ? 'not-allowed' : 'pointer',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color:
                activeIndex <= 0
                  ? 'var(--color-text-faint)'
                  : 'var(--color-text-muted)',
              opacity: activeIndex <= 0 ? 0.5 : 1,
            }}
          >
            <ChevronUp size={18} />
          </button>

          <div
            style={{
              width: 40,
              height: 40,
              borderRadius: 'var(--radius-lg)',
              background: 'var(--color-primary)',
              color: 'white',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontSize: 13,
              fontFamily: 'var(--font-heading)',
              fontWeight: 600,
              boxShadow: 'var(--shadow-md)',
            }}
          >
            {activeIndex + 1}
          </div>

          <button
            onClick={() => {
              const next = Math.min(filteredQuestions.length - 1, activeIndex + 1);
              setActiveIndex(next);
              if (filteredQuestions[next]) {
                scrollToQuestion(filteredQuestions[next].id);
              }
            }}
            disabled={activeIndex >= filteredQuestions.length - 1}
            style={{
              width: 40,
              height: 40,
              borderRadius: 'var(--radius-lg)',
              border: '1px solid var(--color-border)',
              background: 'var(--color-surface-1)',
              boxShadow: 'var(--shadow-sm)',
              cursor:
                activeIndex >= filteredQuestions.length - 1
                  ? 'not-allowed'
                  : 'pointer',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color:
                activeIndex >= filteredQuestions.length - 1
                  ? 'var(--color-text-faint)'
                  : 'var(--color-text-muted)',
              opacity:
                activeIndex >= filteredQuestions.length - 1 ? 0.5 : 1,
            }}
          >
            <ChevronDown size={18} />
          </button>
        </div>
      )}

      {/* Keyboard Help Modal */}
      <KeyboardHelp show={showHelp} onClose={() => setShowHelp(false)} />

      {/* Toast */}
      {toast && (
        <div
          style={{
            position: 'fixed',
            top: 22,
            left: '50%',
            transform: 'translateX(-50%)',
            padding: '9px 22px',
            borderRadius: 'var(--radius-full)',
            background: 'var(--color-text-primary)',
            color: 'var(--color-bg)',
            fontSize: 13,
            fontFamily: 'var(--font-heading)',
            fontWeight: 500,
            boxShadow: 'var(--shadow-lg)',
            zIndex: 200,
            animation: 'toastIn 200ms ease',
          }}
        >
          {toast}
        </div>
      )}

      <style>{`
        @keyframes toastIn {
          from {
            opacity: 0;
            transform: translateX(-50%) translateY(-8px);
          }
          to {
            opacity: 1;
            transform: translateX(-50%) translateY(0);
          }
        }
      `}</style>
    </div>
  );
}
