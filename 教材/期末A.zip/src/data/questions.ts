export type QuestionType = 'choice' | 'fill' | 'short';
export type Difficulty = 'easy' | 'medium' | 'hard';

export interface Question {
  id: string;
  number: string;
  difficulty: Difficulty;
  type: QuestionType;
  stem: string;
  options?: string[];
  answer: string;
  explanation?: string;
}

export const examTitle = "期末综合检测 A 卷";
export const examInfo = "闭卷 120 分钟。40 题。8 选 + 8 填 + 24 问（2:2:6）。易 8 · 中 28 · 难 4。";

export const questions: Question[] = [
  // ===== 选择题 (8题) =====
  {
    id: 'A01',
    number: 'A01',
    difficulty: 'easy',
    type: 'choice',
    stem: 'Rotor 37 是',
    options: [
      'A. 涡轮叶片',
      'B. 跨音速压气机转子',
      'C. 涡扇整机',
      'D. KIT 氢燃机'
    ],
    answer: 'B',
    explanation: 'NASA Rotor 37 是经典的跨音速轴流压气机转子测试用例。A 错（不是涡轮），C 错（不是整机），D 错（KIT 是引子背景）。'
  },
  {
    id: 'A02',
    number: 'A02',
    difficulty: 'easy',
    type: 'choice',
    stem: '冻住的 η 的 $R^2$',
    options: [
      'A. 0.9844',
      'B. 0.9561',
      'C. 0.9827',
      'D. 0.9173'
    ],
    answer: 'B',
    explanation: '三个冻住的 $R^2$：π = 0.9844，η = 0.9561，ṁ = 0.9827。D 是代理预测的最高效率值，不是 $R^2$。'
  },
  {
    id: 'A03',
    number: 'A03',
    difficulty: 'easy',
    type: 'choice',
    stem: '$\\hat C_\\eta=$',
    options: [
      'A. 0.95',
      'B. 0.89',
      'C. 0.65',
      'D. 0.88'
    ],
    answer: 'C',
    explanation: 'η 通道的经验覆盖率 $\\hat C_\\eta \\approx 0.65$（65%），远低于名义 95%，说明 UQ 未校准、区间偏窄。'
  },
  {
    id: 'A04',
    number: 'A04',
    difficulty: 'easy',
    type: 'choice',
    stem: 'relrms = −3.39',
    options: [
      'A. 已收敛',
      'B. 未收敛',
      'C. 误差 3.39%',
      'D. E4'
    ],
    answer: 'B',
    explanation: '残差 relrms = −3.39 未达到收敛阈值（通常需 < −5 或更低），属于 E3（求解器趋势），不是 E4（物理闭环）。'
  },
  {
    id: 'A05',
    number: 'A05',
    difficulty: 'easy',
    type: 'choice',
    stem: '站名',
    options: [
      'A. MDO 平台',
      'B. 气动代理筛选站',
      'C. 可制造优化站',
      'D. TNO 平台'
    ],
    answer: 'B',
    explanation: '法定对外名称是「气动代理筛选站」。A 涉及 MDO（未接入结构/热），C 涉及「可制造」（无几何旋钮），D 是比赛名不是站名。'
  },
  {
    id: 'A06',
    number: 'A06',
    difficulty: 'easy',
    type: 'choice',
    stem: '决策指标现在',
    options: [
      'A. 已填 Spearman',
      'B. 全部 null',
      'C. 只有 HV',
      'D. 代理自比填过'
    ],
    answer: 'B',
    explanation: '当前 decision_metrics 全部为 null，因为没有收敛 RANS 来验证代理预测的排序或增益。'
  },
  {
    id: 'A07',
    number: 'A07',
    difficulty: 'medium',
    type: 'choice',
    stem: '$P$ 是',
    options: [
      'A. 进口总压',
      'B. 背压',
      'C. 叶面静压均值',
      'D. 总温'
    ],
    answer: 'B',
    explanation: '在 74 维特征中，$P$ 指背压（出口静压），是工况变量。A 是 $P_{t,in}$，C 是统计量，D 是温度不是压力。'
  },
  {
    id: 'A08',
    number: 'A08',
    difficulty: 'medium',
    type: 'choice',
    stem: '生产端 UQ',
    options: [
      'A. 实时 100 次 Dropout',
      'B. 预计算常数 σ',
      'C. 已冻结 conformal',
      'D. 不用 σ'
    ],
    answer: 'B',
    explanation: '生产 API 用预计算常数 σ，不是每次请求实时跑 MC Dropout。conformal 校准未完成（在 do_not_freeze 里）。'
  },

  // ===== 填空题 (8题) =====
  {
    id: 'A09',
    number: 'A09',
    difficulty: 'easy',
    type: 'fill',
    stem: '三个输出符号：______、______、______。',
    answer: 'π（压比）；η（效率）；ṁ（流量）',
    explanation: '代理模型预测的三个气动性能指标：总压比 π、等熵效率 η、质量流量 ṁ。'
  },
  {
    id: 'A10',
    number: 'A10',
    difficulty: 'easy',
    type: 'fill',
    stem: '74 = ______ × ______ + Ω + P。',
    answer: '9；8（或 8；9）',
    explanation: '74 维 = 9 截面 × 8 统计量 + 转速 Ω + 背压 P = 72 + 1 + 1 = 74。'
  },
  {
    id: 'A11',
    number: 'A11',
    difficulty: 'medium',
    type: 'fill',
    stem: '$\\Omega$ 单位必须是 ______。',
    answer: 'rad/s（或弧度每秒）',
    explanation: '转速 Ω 必须用 rad/s，不能用 rpm。物理公式中角速度的 SI 单位是 rad/s。'
  },
  {
    id: 'A12',
    number: 'A12',
    difficulty: 'medium',
    type: 'fill',
    stem: '叶尖 $M_{\\mathrm{rel}}\\approx$______（公开基准）。',
    answer: '1.48（或约 1.5）',
    explanation: 'Rotor 37 设计点叶尖相对马赫数约 1.48，属于跨音速范围（有激波）。'
  },
  {
    id: 'A13',
    number: 'A13',
    difficulty: 'medium',
    type: 'fill',
    stem: '八统计量里是 std 不是 ______。',
    answer: 'var（或方差）',
    explanation: '八统计量用标准差 std 而不是方差 var，因为 std 和原始量纲一致，更易解释。'
  },
  {
    id: 'A14',
    number: 'A14',
    difficulty: 'medium',
    type: 'fill',
    stem: '名义带：μ ± ______ σ。',
    answer: '1.96',
    explanation: '名义 95% 置信区间为 μ ± 1.96σ（正态分布双侧 95% 分位点）。'
  },
  {
    id: 'A15',
    number: 'A15',
    difficulty: 'medium',
    type: 'fill',
    stem: '$q > 1.96$ 叫 ______。',
    answer: '离群（或 outlier / 异常）',
    explanation: '标准化残差 q > 1.96 表示真值落在名义 95% 区间外，称为离群点。'
  },
  {
    id: 'A16',
    number: 'A16',
    difficulty: 'medium',
    type: 'fill',
    stem: '$\\dot m_{\\max}\\approx$______ kg/s，该点 η≈______。',
    answer: '20.93；0.842（或约 21；0.84）',
    explanation: '最大流量点约 20.93 kg/s，此时效率约 0.842。这是特性线上的一个工况点。'
  },

  // ===== 简答题 (24题) =====
  {
    id: 'A17',
    number: 'A17',
    difficulty: 'medium',
    type: 'short',
    stem: '总压和静压差在哪个思想实验？',
    answer: '皮托管（Pitot tube）思想实验：将流动完全滞止，动能转化为压力能，滞止后的压力为总压，流动中的压力为静压，差值反映动压（速度）。'
  },
  {
    id: 'A18',
    number: 'A18',
    difficulty: 'medium',
    type: 'short',
    stem: '等熵效率为什么 $\\le 1$。',
    answer: '等熵效率 = 实际做功 / 理想（等熵）做功。由热力学第二定律，实际过程有不可逆损失（激波、摩擦、分离），实际做功 ≤ 理想做功，故 η ≤ 1。'
  },
  {
    id: 'A19',
    number: 'A19',
    difficulty: 'medium',
    type: 'short',
    stem: '正激波后马赫数大于还是小于 1？',
    answer: '小于 1。正激波是超音速 → 亚音速的突变，波后马赫数 $M_2 < 1$。这是由 Rankine-Hugoniot 关系和熵增原理决定的。'
  },
  {
    id: 'A20',
    number: 'A20',
    difficulty: 'medium',
    type: 'short',
    stem: '无滑移条件。',
    answer: '壁面处流体速度等于壁面速度（对静止壁面即速度为零）。这是粘性流动的基本边界条件，由分子层面的粘性力学机制决定。'
  },
  {
    id: 'A21',
    number: 'A21',
    difficulty: 'medium',
    type: 'short',
    stem: '喉部在哪。',
    answer: '喉部是流道最窄处（最小截面积）。对于压气机叶栅，通常在叶片吸力面与相邻叶片压力面之间形成的最小通道处。跨音速时喉部达到音速（M=1）。'
  },
  {
    id: 'A22',
    number: 'A22',
    difficulty: 'medium',
    type: 'short',
    stem: '三种收敛各举本项目现状。',
    answer: '1. RANS 残差收敛：粗网格 relrms = −3.39，未收敛；2. 覆盖率收敛：η 通道 65%，未达名义 95%；3. 蒙特卡洛估计量收敛：MC Dropout 100 次采样，需检查方差是否稳定。'
  },
  {
    id: 'A23',
    number: 'A23',
    difficulty: 'medium',
    type: 'short',
    stem: '偏度为什么不是激波位置。',
    answer: '偏度是分布形状的统计量（三阶矩），只反映不对称程度，不包含空间位置信息。激波位置需要知道「在哪个 x 坐标」，这个信息被截面统计量抹掉了。'
  },
  {
    id: 'A24',
    number: 'A24',
    difficulty: 'medium',
    type: 'short',
    stem: '残差块写 $F(x)+x$ 的意义。',
    answer: '残差连接让网络学习「增量」$F(x)$ 而非完整映射。好处：1. 梯度直通，缓解梯度消失；2. 恒等映射容易学（$F(x)=0$）；3. 深层网络更易训练。'
  },
  {
    id: 'A25',
    number: 'A25',
    difficulty: 'medium',
    type: 'short',
    stem: '边界惩罚为什么不是 PINN。',
    answer: 'PINN 要求在损失里嵌入完整 PDE（如 N-S 方程）的残差。本项目只有物理边界的软惩罚（如进出口守恒），不是 PDE 残差约束，所以不能叫 PINN。'
  },
  {
    id: 'A26',
    number: 'A26',
    difficulty: 'medium',
    type: 'short',
    stem: '$R^2$ 高为什么优化仍不可靠。',
    answer: '$R^2$ 高只说明代理在留出集上拟合好，不保证：1. 外推到训练分布外的最优点；2. 保持正确的排序（Spearman）；3. 增益方向一致。没有收敛 CFD 验证（E4），优化结果不可信。'
  },
  {
    id: 'A27',
    number: 'A27',
    difficulty: 'medium',
    type: 'short',
    stem: '流形 3× 的两个距离。',
    answer: '1. 欧氏距离（特征空间）：74 维向量的 L2 距离；2. 测地距离（流形上）：沿数据流形的最短路径。低维流形上欧氏近的点测地可能远（需绕过流形弯曲）。'
  },
  {
    id: 'A28',
    number: 'A28',
    difficulty: 'medium',
    type: 'short',
    stem: 'Dropout 乘 0 的是什么？',
    answer: 'Dropout 随机将部分神经元输出乘以 0（置零），即「关闭」这些神经元。乘 0 的是隐藏层激活值（或神经元输出），迫使网络不依赖单一神经元，起正则化作用。'
  },
  {
    id: 'A29',
    number: 'A29',
    difficulty: 'medium',
    type: 'short',
    stem: '覆盖率公式（经验）。',
    answer: '$\\hat C = \\frac{1}{n}\\sum_{i=1}^{n} \\mathbf{1}\\{y_i \\in [\\hat\\mu_i - z\\hat\\sigma_i, \\hat\\mu_i + z\\hat\\sigma_i]\\}$，即真值落在预测区间内的样本比例。n 为样本数，z=1.96 对应名义 95%。'
  },
  {
    id: 'A30',
    number: 'A30',
    difficulty: 'medium',
    type: 'short',
    stem: '保形不补什么（至少两点）。',
    answer: '1. 不补偏差（bias）：只调宽度，不修正均值偏移；2. 不补分布形状：只用分位数缩放，不改变预测分布的形态；3. 不补异方差：全局一个 α，不区分不同输入的不确定性。'
  },
  {
    id: 'A31',
    number: 'A31',
    difficulty: 'medium',
    type: 'short',
    stem: '0.9173 必须带的限定。',
    answer: '1.「代理预测的」（不是 CFD）；2.「最高效率」（不是平均）；3.「相对训练均值」（基准是什么）。缺任一限定词都可能暗示物理验证结果，造成越档。'
  },
  {
    id: 'A32',
    number: 'A32',
    difficulty: 'medium',
    type: 'short',
    stem: '3D 是示意还是 CAD？',
    answer: '是示意图（库内近邻可视化），不是 CAD。没有几何旋钮映射回可制造叶片，3D 预览只是展示数据库中相似样本的形状，不能当作优化后的真实几何。'
  },
  {
    id: 'A33',
    number: 'A33',
    difficulty: 'medium',
    type: 'short',
    stem: '为什么不叫 MDO。',
    answer: 'MDO = 多学科设计优化。当前只有气动单学科，没有接入结构强度、热分析等。叫 MDO 是夸大范围，违反证据等级原则。'
  },
  {
    id: 'A34',
    number: 'A34',
    difficulty: 'medium',
    type: 'short',
    stem: 'Level 2 三块铁证。',
    answer: '1. evidence/metrics.json（冻住的 $R^2$ 等数值）；2. evidence/claims.yaml（能对外说的句子及状态）；3. 留出集可复现脚本（seed=42，n=100）。三者共同支撑 E2 级结论。'
  },
  {
    id: 'A35',
    number: 'A35',
    difficulty: 'medium',
    type: 'short',
    stem: '2018 SMO 和 2025 TNO 各一句话。',
    answer: '2018 SMO：早期代理模型优化探索，建立了基本框架但数据量和精度有限。2025 TNO：提供 Rotor 37 大规模 CFD 数据集和评测标准，是本项目的数据来源和基准。'
  },
  {
    id: 'A36',
    number: 'A36',
    difficulty: 'medium',
    type: 'short',
    stem: '改错：「校准的 95% CI，η 盖住 65%。」',
    answer: '错误：1.「校准的」——未校准，conformal 在 do_not_freeze；2.「盖住 65%」说明是未校准的名义 95% CI。改为：「名义 95% CI，η 经验覆盖率约 65%，未校准。」'
  },
  {
    id: 'A37',
    number: 'A37',
    difficulty: 'hard',
    type: 'short',
    stem: '用权重 / 覆盖率 / 加宽写三句（Q4）。',
    answer: '1. 权重句：MC Dropout 对每个神经元以概率 p 置零，推理时保留 Dropout 采样 100 次，用均值作预测、标准差作不确定性。2. 覆盖率句：η 通道名义 95% CI 只盖住约 65% 真值，说明 σ 估计偏窄、区间过度自信。3. 加宽句：conformal 用留出集找分位数 α 将区间加宽，使经验覆盖率提升到名义水平（如 95%）。'
  },
  {
    id: 'A38',
    number: 'A38',
    difficulty: 'hard',
    type: 'short',
    stem: '「这是不是已经优化出好叶子？」三句以内。',
    answer: '代理模型在留出集上 $R^2$ 达到 0.96，筛出了特征空间的非支配解（代理预测最高效率约 0.9173）。但这是 74 维统计量空间，没有几何旋钮映射回可制造叶片。收敛 CFD 验证（E4）还没完成，所以不能说「优化出好叶子」。'
  },
  {
    id: 'A39',
    number: 'A39',
    difficulty: 'hard',
    type: 'short',
    stem: '从激波位置被 74 维抹掉推到 $\\hat C_\\eta=0.65$，不少于四步，每步标档。',
    answer: '1. [E1] 74 维是截面统计量，激波位置（空间坐标）信息被抹掉；2. [E1] 统计量分布相同但激波位置不同的叶片会被映射到相近特征；3. [E2] 代理在特征空间拟合，对物理上不同的叶片给出相似预测和不确定性；4. [E2] 当真实效率因激波差异而不同时，预测区间盖不住真值，导致 $\\hat C_\\eta$ 只有 65%；5. [推论] 不确定性低估源于输入表征丢失了关键物理信息。'
  },
  {
    id: 'A40',
    number: 'A40',
    difficulty: 'hard',
    type: 'short',
    stem: '第一轮 8 个收敛 RANS 的取样表，并指出哪些决策指标能填。',
    answer: '取样策略：1. Pareto 前沿 Top-3（高 η、高 π、平衡点）；2. 代理预测最大 η 和最大 π 各 1 个；3. 训练集边界 2 个（检验外推）；4. 随机 1 个（基线）。能填的决策指标：Spearman 排序相关（需 ≥ 5 对比较）、Top-k 命中率（k=3）、局部增益方向（η 或 π 是否真的提升）。HV 需要更多点。'
  }
];

// Get questions by type
export function getQuestionsByType(type: QuestionType): Question[] {
  return questions.filter(q => q.type === type);
}

// Get questions by difficulty
export function getQuestionsByDifficulty(difficulty: Difficulty): Question[] {
  return questions.filter(q => q.difficulty === difficulty);
}

// Stats
export function getStats() {
  const byType = {
    choice: questions.filter(q => q.type === 'choice').length,
    fill: questions.filter(q => q.type === 'fill').length,
    short: questions.filter(q => q.type === 'short').length,
  };
  const byDifficulty = {
    easy: questions.filter(q => q.difficulty === 'easy').length,
    medium: questions.filter(q => q.difficulty === 'medium').length,
    hard: questions.filter(q => q.difficulty === 'hard').length,
  };
  return { byType, byDifficulty, total: questions.length };
}
