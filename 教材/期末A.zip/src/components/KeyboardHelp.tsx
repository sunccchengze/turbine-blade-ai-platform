import { Keyboard } from 'lucide-react';

interface KeyboardHelpProps {
  show: boolean;
  onClose: () => void;
}

const shortcuts = [
  { keys: ['↑', 'K'], desc: '上一题' },
  { keys: ['↓', 'J'], desc: '下一题' },
  { keys: ['Space'], desc: '展开/收起答案' },
  { keys: ['M'], desc: '标记/取消掌握' },
  { keys: ['A'], desc: '展开所有答案' },
  { keys: ['H'], desc: '只看未掌握的题' },
  { keys: ['1'], desc: '筛选：选择题' },
  { keys: ['2'], desc: '筛选：填空题' },
  { keys: ['3'], desc: '筛选：简答题' },
  { keys: ['0'], desc: '显示全部题型' },
  { keys: ['R'], desc: '重置所有进度' },
  { keys: ['?'], desc: '显示/隐藏快捷键' },
  { keys: ['Home'], desc: '跳到第一题' },
  { keys: ['End'], desc: '跳到最后一题' },
];

export default function KeyboardHelp({ show, onClose }: KeyboardHelpProps) {
  if (!show) return null;

  return (
    <div
      style={{
        position: 'fixed',
        inset: 0,
        zIndex: 100,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        background: 'rgba(20,20,19,0.5)',
        backdropFilter: 'blur(4px)',
      }}
      onClick={onClose}
    >
      <div
        onClick={e => e.stopPropagation()}
        style={{
          background: 'var(--color-surface-1)',
          borderRadius: 'var(--radius-xl)',
          boxShadow: 'var(--shadow-lg)',
          padding: '28px 32px',
          maxWidth: 420,
          width: '90%',
        }}
      >
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: 10,
            marginBottom: 20,
          }}
        >
          <Keyboard size={20} color="var(--color-primary)" strokeWidth={1.5} />
          <h2
            style={{
              fontFamily: 'var(--font-heading)',
              fontSize: 20,
              fontWeight: 600,
              color: 'var(--color-text-primary)',
              margin: 0,
            }}
          >
            键盘快捷键
          </h2>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {shortcuts.map((s, i) => (
            <div
              key={i}
              style={{
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                padding: '5px 0',
                borderBottom:
                  i < shortcuts.length - 1
                    ? '1px solid var(--color-border-faint)'
                    : 'none',
              }}
            >
              <span
                style={{
                  fontSize: 14,
                  color: 'var(--color-text-primary)',
                  fontFamily: 'var(--font-body)',
                }}
              >
                {s.desc}
              </span>
              <div style={{ display: 'flex', gap: 4 }}>
                {s.keys.map((k, j) => (
                  <span key={j}>
                    {j > 0 && (
                      <span
                        style={{
                          color: 'var(--color-text-faint)',
                          fontSize: 11,
                          margin: '0 2px',
                        }}
                      >
                        /
                      </span>
                    )}
                    <kbd
                      style={{
                        display: 'inline-block',
                        padding: '2px 7px',
                        borderRadius: 'var(--radius-sm)',
                        background: 'var(--color-surface-2)',
                        border: '1px solid var(--color-border)',
                        boxShadow: '0 1px 0 var(--color-border)',
                        fontSize: 12,
                        fontFamily: 'var(--font-mono)',
                        color: 'var(--color-text-primary)',
                        fontWeight: 500,
                        minWidth: 24,
                        textAlign: 'center',
                      }}
                    >
                      {k}
                    </kbd>
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>

        <button
          onClick={onClose}
          style={{
            marginTop: 20,
            width: '100%',
            padding: '9px 18px',
            borderRadius: 'var(--radius-md)',
            border: 'none',
            background: 'var(--color-primary)',
            color: 'white',
            fontSize: 13,
            fontFamily: 'var(--font-heading)',
            fontWeight: 500,
            cursor: 'pointer',
          }}
        >
          知道了
        </button>
      </div>
    </div>
  );
}
