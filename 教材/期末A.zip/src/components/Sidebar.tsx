import type { Question, QuestionType, Difficulty } from '../data/questions';
import { CheckCircle, BookOpen, PenLine, MessageSquare } from 'lucide-react';

interface SidebarProps {
  questions: Question[];
  activeIndex: number;
  onQuestionSelect: (index: number) => void;
  mastered: Set<string>;
  totalQuestions: number;
  totalMastered: number;
  filterType: QuestionType | 'all';
  onFilterTypeChange: (type: QuestionType | 'all') => void;
  filterDifficulty: Difficulty | 'all';
  onFilterDifficultyChange: (diff: Difficulty | 'all') => void;
}

const typeIcons: Record<string, typeof BookOpen> = {
  choice: BookOpen,
  fill: PenLine,
  short: MessageSquare,
};

const typeLabels: Record<string, string> = {
  choice: '选择',
  fill: '填空',
  short: '简答',
};

const diffLabels: Record<string, string> = {
  easy: '易',
  medium: '中',
  hard: '难',
};

const diffColors: Record<string, string> = {
  easy: '#6A8C5F',
  medium: '#C9973B',
  hard: '#B84A3A',
};

export default function Sidebar({
  questions,
  activeIndex,
  onQuestionSelect,
  mastered,
  totalQuestions,
  totalMastered,
  filterType,
  onFilterTypeChange,
  filterDifficulty,
  onFilterDifficultyChange,
}: SidebarProps) {
  const progress = totalQuestions > 0 ? (totalMastered / totalQuestions) * 100 : 0;

  return (
    <aside
      style={{
        width: 260,
        minWidth: 260,
        height: '100vh',
        position: 'sticky',
        top: 0,
        background: 'var(--color-surface-1)',
        borderRight: '1px solid var(--color-border-faint)',
        display: 'flex',
        flexDirection: 'column',
        overflow: 'hidden',
      }}
    >
      {/* Logo */}
      <div
        style={{
          padding: '20px 16px 14px',
          borderBottom: '1px solid var(--color-border-faint)',
        }}
      >
        <h1
          style={{
            fontFamily: 'var(--font-heading)',
            fontSize: 15,
            fontWeight: 700,
            color: 'var(--color-text-primary)',
            margin: 0,
            letterSpacing: '-0.02em',
          }}
        >
          📝 期末综合检测 A 卷
        </h1>
        <p
          style={{
            fontFamily: 'var(--font-heading)',
            fontSize: 11,
            color: 'var(--color-text-muted)',
            margin: '4px 0 0',
          }}
        >
          40 题 · 120 分钟 · 闭卷
        </p>

        {/* Progress bar */}
        <div style={{ marginTop: 12 }}>
          <div
            style={{
              display: 'flex',
              justifyContent: 'space-between',
              fontSize: 11,
              fontFamily: 'var(--font-heading)',
              color: 'var(--color-text-muted)',
              marginBottom: 5,
            }}
          >
            <span>掌握进度</span>
            <span>
              {totalMastered}/{totalQuestions}
            </span>
          </div>
          <div
            style={{
              height: 5,
              borderRadius: 'var(--radius-full)',
              background: 'var(--color-surface-2)',
              overflow: 'hidden',
            }}
          >
            <div
              style={{
                height: '100%',
                width: `${progress}%`,
                borderRadius: 'var(--radius-full)',
                background: 'var(--color-success)',
                transition: 'width 400ms cubic-bezier(0.4, 0, 0.2, 1)',
              }}
            />
          </div>
        </div>
      </div>

      {/* Type filter */}
      <div
        style={{
          padding: '10px 12px 6px',
          borderBottom: '1px solid var(--color-border-faint)',
        }}
      >
        <div style={{ fontSize: 11, color: 'var(--color-text-faint)', marginBottom: 6, fontFamily: 'var(--font-heading)' }}>
          题型筛选
        </div>
        <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap' }}>
          {(['all', 'choice', 'fill', 'short'] as const).map((t) => (
            <button
              key={t}
              onClick={() => onFilterTypeChange(t)}
              style={{
                padding: '4px 8px',
                borderRadius: 'var(--radius-full)',
                border: filterType === t
                  ? '1px solid var(--color-primary)'
                  : '1px solid var(--color-border)',
                background: filterType === t
                  ? 'var(--color-primary-soft)'
                  : 'transparent',
                color: filterType === t
                  ? 'var(--color-primary-dark)'
                  : 'var(--color-text-muted)',
                fontSize: 11,
                fontFamily: 'var(--font-heading)',
                fontWeight: 500,
                cursor: 'pointer',
              }}
            >
              {t === 'all' ? '全部' : typeLabels[t]}
            </button>
          ))}
        </div>
      </div>

      {/* Difficulty filter */}
      <div
        style={{
          padding: '8px 12px 10px',
          borderBottom: '1px solid var(--color-border-faint)',
        }}
      >
        <div style={{ fontSize: 11, color: 'var(--color-text-faint)', marginBottom: 6, fontFamily: 'var(--font-heading)' }}>
          难度筛选
        </div>
        <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap' }}>
          {(['all', 'easy', 'medium', 'hard'] as const).map((d) => (
            <button
              key={d}
              onClick={() => onFilterDifficultyChange(d)}
              style={{
                padding: '4px 8px',
                borderRadius: 'var(--radius-full)',
                border: filterDifficulty === d
                  ? `1px solid ${d === 'all' ? 'var(--color-primary)' : diffColors[d]}`
                  : '1px solid var(--color-border)',
                background: filterDifficulty === d
                  ? d === 'all' ? 'var(--color-primary-soft)' : `${diffColors[d]}15`
                  : 'transparent',
                color: filterDifficulty === d
                  ? d === 'all' ? 'var(--color-primary-dark)' : diffColors[d]
                  : 'var(--color-text-muted)',
                fontSize: 11,
                fontFamily: 'var(--font-heading)',
                fontWeight: 500,
                cursor: 'pointer',
              }}
            >
              {d === 'all' ? '全部' : diffLabels[d]}
            </button>
          ))}
        </div>
      </div>

      {/* Questions list */}
      <div
        style={{
          flex: 1,
          overflowY: 'auto',
          padding: '8px 10px 16px',
        }}
      >
        {questions.map((q, i) => {
          const Icon = typeIcons[q.type] || BookOpen;
          const isMastered = mastered.has(q.id);
          const isActive = i === activeIndex;
          const diffColor = diffColors[q.difficulty];

          return (
            <button
              key={q.id}
              onClick={() => onQuestionSelect(i)}
              style={{
                width: '100%',
                display: 'flex',
                alignItems: 'center',
                gap: 6,
                padding: '7px 8px',
                marginBottom: 2,
                borderRadius: 'var(--radius-md)',
                border: 'none',
                background: isActive
                  ? 'var(--color-primary-soft)'
                  : 'transparent',
                cursor: 'pointer',
                textAlign: 'left',
                transition: 'all 150ms ease',
              }}
            >
              <Icon
                size={13}
                strokeWidth={1.5}
                color={
                  isActive
                    ? 'var(--color-primary-dark)'
                    : 'var(--color-text-faint)'
                }
              />
              <span
                style={{
                  fontSize: 13,
                  fontFamily: 'var(--font-mono)',
                  color: isActive
                    ? 'var(--color-primary-dark)'
                    : 'var(--color-text-primary)',
                  fontWeight: isActive ? 600 : 400,
                }}
              >
                {q.number}
              </span>
              <span
                style={{
                  fontSize: 10,
                  fontFamily: 'var(--font-heading)',
                  color: diffColor,
                  fontWeight: 500,
                  marginLeft: 'auto',
                }}
              >
                {diffLabels[q.difficulty]}
              </span>
              {isMastered && (
                <CheckCircle
                  size={13}
                  color="var(--color-success)"
                  strokeWidth={2}
                />
              )}
            </button>
          );
        })}
      </div>

      {/* Footer */}
      <div
        style={{
          padding: '10px 14px',
          borderTop: '1px solid var(--color-border-faint)',
          fontSize: 11,
          color: 'var(--color-text-faint)',
          fontFamily: 'var(--font-heading)',
          display: 'flex',
          alignItems: 'center',
          gap: 5,
        }}
      >
        按
        <kbd
          style={{
            padding: '1px 4px',
            borderRadius: 3,
            background: 'var(--color-surface-2)',
            border: '1px solid var(--color-border)',
            fontSize: 10,
            fontFamily: 'var(--font-mono)',
          }}
        >
          ?
        </kbd>
        查看快捷键
      </div>
    </aside>
  );
}
