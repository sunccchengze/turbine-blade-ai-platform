import { useMemo } from 'react';
import katex from 'katex';

interface MathTextProps {
  text: string;
  className?: string;
}

function renderMath(text: string): string {
  // Process code blocks first: ```...```
  let result = text.replace(/```([\s\S]*?)```/g, (_, code) => {
    return `<pre><code>${code.trim().replace(/</g, '&lt;').replace(/>/g, '&gt;')}</code></pre>`;
  });

  // Process inline code: `...`
  result = result.replace(/`([^`\n]+?)`/g, '<code>$1</code>');

  // Process display math: $$...$$
  result = result.replace(/\$\$([\s\S]*?)\$\$/g, (_, math) => {
    try {
      return katex.renderToString(math.trim(), {
        displayMode: true,
        throwOnError: false,
        trust: true,
        strict: false,
      });
    } catch {
      return `<span class="math-error">${math}</span>`;
    }
  });

  // Process inline math: $...$
  result = result.replace(/\$([^\$\n]+?)\$/g, (_, math) => {
    try {
      return katex.renderToString(math.trim(), {
        displayMode: false,
        throwOnError: false,
        trust: true,
        strict: false,
      });
    } catch {
      return `<span class="math-error">${math}</span>`;
    }
  });

  // Process tables: | ... | ... |
  const tableRegex = /\n\|(.+)\|\n\|[-|\s:]+\|\n((?:\|.+\|\n?)+)/g;
  result = result.replace(tableRegex, (_, headerRow, bodyRows) => {
    const headers = headerRow.split('|').map((h: string) => h.trim()).filter(Boolean);
    const rows = bodyRows.trim().split('\n').map((row: string) => 
      row.split('|').map((cell: string) => cell.trim()).filter(Boolean)
    );
    
    let table = '<table><thead><tr>';
    headers.forEach((h: string) => {
      table += `<th>${h}</th>`;
    });
    table += '</tr></thead><tbody>';
    rows.forEach((row: string[]) => {
      table += '<tr>';
      row.forEach((cell: string) => {
        table += `<td>${cell}</td>`;
      });
      table += '</tr>';
    });
    table += '</tbody></table>';
    return table;
  });

  // Process bold **text**
  result = result.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');

  // Process horizontal rules ---
  result = result.replace(/\n---\n/g, '<hr/>');

  // Process ordered lists
  result = result.replace(/^(\d+)\.\s+(.+)$/gm, '<li>$2</li>');
  result = result.replace(/(<li>.*<\/li>\n?)+/g, '<ol>$&</ol>');

  // Process unordered lists
  result = result.replace(/^[-•]\s+(.+)$/gm, '<li class="ul">$1</li>');
  result = result.replace(/(<li class="ul">.*<\/li>\n?)+/g, (match) => {
    return '<ul>' + match.replace(/ class="ul"/g, '') + '</ul>';
  });

  // Process line breaks
  result = result.replace(/\n\n/g, '</p><p>');
  result = result.replace(/\n/g, '<br/>');

  return `<div>${result}</div>`;
}

export default function MathText({ text, className = '' }: MathTextProps) {
  const html = useMemo(() => renderMath(text), [text]);

  return (
    <div
      className={className}
      dangerouslySetInnerHTML={{ __html: html }}
      style={{ lineHeight: 1.8 }}
    />
  );
}
